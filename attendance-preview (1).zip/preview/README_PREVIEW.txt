ATTENDANCE AI SYSTEM — OFFLINE OUTPUT PREVIEW
==============================================

This is a ready-to-open preview of your project's actual frontend
(unchanged HTML/CSS/JS from your zip), running against a simulated
backend seeded with your own database/sample_data.sql, so you can see
exactly what the finished app looks like WITHOUT installing Java,
Maven, MySQL, or Python, and without running any commands.

HOW TO OPEN
-----------
1. Unzip this folder anywhere.
2. Double-click "login.html" to open it in your browser (Chrome/Edge/Firefox).
   That's it — no server, no npm/mvn/mysql commands needed.

DEMO LOGINS
-----------
Admin:    admin / admin123
Faculty:  faculty1 / faculty123   (or faculty2 .. faculty5)
Student:  student1 / student123   (or student2 .. student20)

WHAT YOU CAN TRY
-----------------
- Admin: view dashboard charts, manage students/faculty/subjects,
  see analytics, AI predictions, leave requests, reports.
- Faculty: mark attendance for a subject/date (this instantly creates
  parent notifications for anyone marked absent), run AI predictions,
  approve/reject leave requests.
- Student: view attendance %, apply for leave, run "Get My Prediction".

Data you enter (new students, attendance you mark, leave you apply for,
predictions you run) is kept for your browser tab only (sessionStorage)
and resets when you close the tab — it never touches a real database.

WHAT THIS IS NOT
-----------------
This is a stand-in for the real backend, not the real backend itself.
Your actual project (backend/ = Spring Boot + MySQL, ai_model/ = Flask +
scikit-learn) still needs Java 17, Maven, MySQL and Python to actually
run for submission/demo purposes — see the project's own README.md and
TESTING.md for that. This preview exists purely so you can see the UI
and behavior without setting all of that up first.

A small blue banner at the bottom of every page reminds you this is the
offline preview; click it to dismiss.

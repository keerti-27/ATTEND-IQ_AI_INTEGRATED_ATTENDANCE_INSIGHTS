package com.college.attendance.controller;

import com.college.attendance.dto.ApiResponse;
import com.college.attendance.dto.StudentRequest;
import com.college.attendance.model.Student;
import com.college.attendance.service.StudentService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Student management is an ADMIN capability (add/edit/delete/search students),
 * exposed under /api/admin/students so the SessionAuthFilter enforces ADMIN-only access.
 */
@RestController
@RequestMapping("/api/admin/students")
public class StudentController {

    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @GetMapping
    public ApiResponse<List<Student>> getAll(@RequestParam(required = false) String search) {
        List<Student> students = (search == null || search.isBlank())
                ? studentService.getAll() : studentService.search(search);
        return ApiResponse.ok(students);
    }

    @GetMapping("/{id}")
    public ApiResponse<Student> getById(@PathVariable Long id) {
        return ApiResponse.ok(studentService.getById(id));
    }

    @PostMapping
    public ApiResponse<Student> create(@Valid @RequestBody StudentRequest request) {
        return ApiResponse.ok("Student created successfully", studentService.create(request));
    }

    @PutMapping("/{id}")
    public ApiResponse<Student> update(@PathVariable Long id, @Valid @RequestBody StudentRequest request) {
        return ApiResponse.ok("Student updated successfully", studentService.update(id, request));
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Object> delete(@PathVariable Long id) {
        studentService.delete(id);
        return ApiResponse.ok("Student deleted successfully", null);
    }
}

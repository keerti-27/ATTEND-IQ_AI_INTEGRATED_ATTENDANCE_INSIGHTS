package com.college.attendance.service;

import com.college.attendance.dto.LoginRequest;
import com.college.attendance.dto.LoginResponse;
import com.college.attendance.exception.UnauthorizedException;
import com.college.attendance.model.Faculty;
import com.college.attendance.model.Student;
import com.college.attendance.model.User;
import com.college.attendance.repository.FacultyRepository;
import com.college.attendance.repository.StudentRepository;
import com.college.attendance.repository.UserRepository;
import com.college.attendance.util.PasswordUtil;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final StudentRepository studentRepository;
    private final FacultyRepository facultyRepository;

    public AuthService(UserRepository userRepository, StudentRepository studentRepository, FacultyRepository facultyRepository) {
        this.userRepository = userRepository;
        this.studentRepository = studentRepository;
        this.facultyRepository = facultyRepository;
    }

    public LoginResponse login(LoginRequest request) {
        String role = request.getRole() == null ? "" : request.getRole().toUpperCase();

        User user = userRepository.findByUsernameAndRole(request.getUsername(), role)
                .orElseThrow(() -> new UnauthorizedException("Invalid username, password, or role"));

        if (!PasswordUtil.verifyPassword(request.getPassword(), user.getPasswordHash())) {
            throw new UnauthorizedException("Invalid username, password, or role");
        }

        String displayName = resolveDisplayName(user);
        return new LoginResponse(user.getUsername(), user.getRole(), user.getReferenceId(), displayName);
    }

    private String resolveDisplayName(User user) {
        if ("ADMIN".equals(user.getRole())) {
            return "Administrator";
        }
        if ("FACULTY".equals(user.getRole())) {
            Optional<Faculty> f = facultyRepository.findByCode(user.getReferenceId());
            return f.map(Faculty::getName).orElse(user.getUsername());
        }
        if ("STUDENT".equals(user.getRole())) {
            Optional<Student> s = studentRepository.findByCode(user.getReferenceId());
            return s.map(Student::getName).orElse(user.getUsername());
        }
        return user.getUsername();
    }

    /** Used when admin creates a new student/faculty login. */
    public void createUserAccount(String username, String plainPassword, String role, String referenceId) {
        if (userRepository.existsByUsername(username)) {
            throw new UnauthorizedException("Username already exists: " + username);
        }
        User user = new User();
        user.setUsername(username);
        user.setPasswordHash(PasswordUtil.hashPassword(plainPassword));
        user.setRole(role);
        user.setReferenceId(referenceId);
        userRepository.save(user);
    }
}

package com.college.attendance.service;

import com.college.attendance.dto.LeaveApplyRequest;
import com.college.attendance.exception.BadRequestException;
import com.college.attendance.exception.ResourceNotFoundException;
import com.college.attendance.model.LeaveRequest;
import com.college.attendance.repository.LeaveRequestRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LeaveService {

    private final LeaveRequestRepository leaveRequestRepository;

    public LeaveService(LeaveRequestRepository leaveRequestRepository) {
        this.leaveRequestRepository = leaveRequestRepository;
    }

    public LeaveRequest apply(LeaveApplyRequest req) {
        if (req.getToDate().isBefore(req.getFromDate())) {
            throw new BadRequestException("'To date' cannot be before 'From date'");
        }
        LeaveRequest l = new LeaveRequest();
        l.setStudentId(req.getStudentId());
        l.setFromDate(req.getFromDate());
        l.setToDate(req.getToDate());
        l.setReason(req.getReason());
        l.setStatus("PENDING");
        Long id = leaveRequestRepository.save(l);
        l.setLeaveId(id);
        return l;
    }

    public List<LeaveRequest> getForStudent(Long studentId) {
        return leaveRequestRepository.findByStudent(studentId);
    }

    public List<LeaveRequest> getPending() {
        return leaveRequestRepository.findPending();
    }

    public List<LeaveRequest> getAll() {
        return leaveRequestRepository.findAll();
    }

    public void decide(Long leaveId, String decision, Long reviewerFacultyId) {
        LeaveRequest existing = leaveRequestRepository.findById(leaveId)
                .orElseThrow(() -> new ResourceNotFoundException("Leave request not found: " + leaveId));

        String normalized = decision == null ? "" : decision.toUpperCase();
        if (!normalized.equals("APPROVED") && !normalized.equals("REJECTED")) {
            throw new BadRequestException("Decision must be APPROVED or REJECTED");
        }
        if (!"PENDING".equals(existing.getStatus())) {
            throw new BadRequestException("This leave request has already been reviewed");
        }
        leaveRequestRepository.updateDecision(leaveId, normalized, reviewerFacultyId);
    }
}

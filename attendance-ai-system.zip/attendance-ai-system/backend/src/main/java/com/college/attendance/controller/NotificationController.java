package com.college.attendance.controller;

import com.college.attendance.dto.ApiResponse;
import com.college.attendance.exception.ResourceNotFoundException;
import com.college.attendance.model.Notification;
import com.college.attendance.model.Student;
import com.college.attendance.repository.StudentRepository;
import com.college.attendance.service.NotificationService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class NotificationController {

    private final NotificationService notificationService;
    private final StudentRepository studentRepository;

    public NotificationController(NotificationService notificationService, StudentRepository studentRepository) {
        this.notificationService = notificationService;
        this.studentRepository = studentRepository;
    }

    @GetMapping("/api/faculty/notifications")
    public ApiResponse<List<Notification>> all() {
        return ApiResponse.ok(notificationService.getAll());
    }

    @GetMapping("/api/student/notifications/mine")
    public ApiResponse<List<Notification>> mine(HttpServletRequest request) {
        String studentCode = (String) request.getSession().getAttribute("referenceId");
        Student student = studentRepository.findByCode(studentCode)
                .orElseThrow(() -> new ResourceNotFoundException("Student session invalid"));
        return ApiResponse.ok(notificationService.getForStudent(student.getStudentId()));
    }
}

package com.college.attendance.repository;

import com.college.attendance.model.Notification;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class NotificationRepository {

    private final JdbcTemplate jdbcTemplate;

    public NotificationRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Notification> ROW_MAPPER = (rs, rowNum) -> {
        Notification n = new Notification();
        n.setNotificationId(rs.getLong("notification_id"));
        n.setStudentId(rs.getLong("student_id"));
        n.setParentName(rs.getString("parent_name"));
        n.setParentEmail(rs.getString("parent_email"));
        n.setMessage(rs.getString("message"));
        n.setNotificationDate(rs.getTimestamp("notification_date").toLocalDateTime());
        n.setStatus(rs.getString("status"));
        return n;
    };

    public void save(Notification n) {
        jdbcTemplate.update(
                "INSERT INTO notifications (student_id, parent_name, parent_email, message, status) VALUES (?, ?, ?, ?, ?)",
                n.getStudentId(), n.getParentName(), n.getParentEmail(), n.getMessage(), n.getStatus());
    }

    public List<Notification> findByStudent(Long studentId) {
        return jdbcTemplate.query(
                "SELECT * FROM notifications WHERE student_id = ? ORDER BY notification_date DESC", ROW_MAPPER, studentId);
    }

    public List<Notification> findAll() {
        return jdbcTemplate.query("SELECT * FROM notifications ORDER BY notification_date DESC LIMIT 200", ROW_MAPPER);
    }
}

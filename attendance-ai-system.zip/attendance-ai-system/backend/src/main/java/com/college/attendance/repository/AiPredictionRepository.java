package com.college.attendance.repository;

import com.college.attendance.model.AiPrediction;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public class AiPredictionRepository {

    private final JdbcTemplate jdbcTemplate;

    public AiPredictionRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<AiPrediction> ROW_MAPPER = (rs, rowNum) -> {
        AiPrediction p = new AiPrediction();
        p.setPredictionId(rs.getLong("prediction_id"));
        p.setStudentId(rs.getLong("student_id"));
        p.setCurrentAttendance(rs.getBigDecimal("current_attendance"));
        p.setPredictedAttendance(rs.getBigDecimal("predicted_attendance"));
        p.setRiskLevel(rs.getString("risk_level"));
        p.setMessage(rs.getString("message"));
        p.setPredictedAt(rs.getTimestamp("predicted_at").toLocalDateTime());
        return p;
    };

    public void save(Long studentId, BigDecimal currentAttendance, BigDecimal predictedAttendance, String riskLevel, String message) {
        jdbcTemplate.update(
                "INSERT INTO ai_predictions (student_id, current_attendance, predicted_attendance, risk_level, message) VALUES (?, ?, ?, ?, ?)",
                studentId, currentAttendance, predictedAttendance, riskLevel, message);
    }

    public List<AiPrediction> findLatestPerStudent() {
        return jdbcTemplate.query(
                "SELECT p1.* FROM ai_predictions p1 "
                        + "INNER JOIN (SELECT student_id, MAX(predicted_at) AS max_date FROM ai_predictions GROUP BY student_id) p2 "
                        + "ON p1.student_id = p2.student_id AND p1.predicted_at = p2.max_date", ROW_MAPPER);
    }

    public List<AiPrediction> findByStudent(Long studentId) {
        return jdbcTemplate.query(
                "SELECT * FROM ai_predictions WHERE student_id = ? ORDER BY predicted_at DESC", ROW_MAPPER, studentId);
    }

    public long countHighRisk() {
        Long c = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM ai_predictions p1 "
                        + "INNER JOIN (SELECT student_id, MAX(predicted_at) AS max_date FROM ai_predictions GROUP BY student_id) p2 "
                        + "ON p1.student_id = p2.student_id AND p1.predicted_at = p2.max_date "
                        + "WHERE p1.risk_level = 'HIGH'", Long.class);
        return c != null ? c : 0;
    }
}

package com.college.attendance.controller;

import com.college.attendance.dto.AiPredictionResult;
import com.college.attendance.dto.ApiResponse;
import com.college.attendance.exception.ResourceNotFoundException;
import com.college.attendance.model.AiPrediction;
import com.college.attendance.model.Student;
import com.college.attendance.repository.StudentRepository;
import com.college.attendance.service.AiPredictionService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class AiPredictionController {

    private final AiPredictionService aiPredictionService;
    private final StudentRepository studentRepository;

    public AiPredictionController(AiPredictionService aiPredictionService, StudentRepository studentRepository) {
        this.aiPredictionService = aiPredictionService;
        this.studentRepository = studentRepository;
    }

    // ---- FACULTY / ADMIN: predict for any student, and view the latest table ----
    @PostMapping("/api/faculty/ai/predict/{studentId}")
    public ApiResponse<AiPredictionResult> predict(@PathVariable Long studentId) {
        return ApiResponse.ok(aiPredictionService.predictForStudent(studentId));
    }

    @GetMapping("/api/faculty/ai/latest")
    public ApiResponse<List<AiPrediction>> latest() {
        return ApiResponse.ok(aiPredictionService.getLatestForAllStudents());
    }

    @GetMapping("/api/faculty/ai/history/{studentId}")
    public ApiResponse<List<AiPrediction>> history(@PathVariable Long studentId) {
        return ApiResponse.ok(aiPredictionService.getHistoryForStudent(studentId));
    }

    // ---- STUDENT: predict / view own ----
    @PostMapping("/api/student/ai/predict/me")
    public ApiResponse<AiPredictionResult> predictMe(HttpServletRequest request) {
        Student student = currentStudent(request);
        return ApiResponse.ok(aiPredictionService.predictForStudent(student.getStudentId()));
    }

    @GetMapping("/api/student/ai/history/me")
    public ApiResponse<List<AiPrediction>> historyMe(HttpServletRequest request) {
        Student student = currentStudent(request);
        return ApiResponse.ok(aiPredictionService.getHistoryForStudent(student.getStudentId()));
    }

    private Student currentStudent(HttpServletRequest request) {
        String studentCode = (String) request.getSession().getAttribute("referenceId");
        return studentRepository.findByCode(studentCode)
                .orElseThrow(() -> new ResourceNotFoundException("Student session invalid"));
    }
}

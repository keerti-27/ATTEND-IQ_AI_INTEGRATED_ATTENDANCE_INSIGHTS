package com.college.attendance.dto;

public class AiPredictionResult {
    private Long studentId;
    private String studentCode;
    private String studentName;
    private double currentAttendance;
    private double predictedAttendance;
    private String riskLevel;
    private String message;

    public AiPredictionResult() {}

    public Long getStudentId() { return studentId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }
    public String getStudentCode() { return studentCode; }
    public void setStudentCode(String studentCode) { this.studentCode = studentCode; }
    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }
    public double getCurrentAttendance() { return currentAttendance; }
    public void setCurrentAttendance(double currentAttendance) { this.currentAttendance = currentAttendance; }
    public double getPredictedAttendance() { return predictedAttendance; }
    public void setPredictedAttendance(double predictedAttendance) { this.predictedAttendance = predictedAttendance; }
    public String getRiskLevel() { return riskLevel; }
    public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
}

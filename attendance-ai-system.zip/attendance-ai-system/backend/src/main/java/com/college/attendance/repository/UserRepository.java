package com.college.attendance.repository;

import com.college.attendance.model.User;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class UserRepository {

    private final JdbcTemplate jdbcTemplate;

    public UserRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<User> ROW_MAPPER = (rs, rowNum) -> {
        User u = new User();
        u.setUserId(rs.getLong("user_id"));
        u.setUsername(rs.getString("username"));
        u.setPasswordHash(rs.getString("password_hash"));
        u.setRole(rs.getString("role"));
        u.setReferenceId(rs.getString("reference_id"));
        u.setActive(rs.getBoolean("is_active"));
        u.setCreatedAt(rs.getTimestamp("created_at") != null ? rs.getTimestamp("created_at").toLocalDateTime() : null);
        return u;
    };

    public Optional<User> findByUsernameAndRole(String username, String role) {
        List<User> results = jdbcTemplate.query(
                "SELECT * FROM users WHERE username = ? AND role = ? AND is_active = TRUE",
                ROW_MAPPER, username, role);
        return results.stream().findFirst();
    }

    public Optional<User> findByUsername(String username) {
        List<User> results = jdbcTemplate.query(
                "SELECT * FROM users WHERE username = ?", ROW_MAPPER, username);
        return results.stream().findFirst();
    }

    public User save(User user) {
        jdbcTemplate.update(
                "INSERT INTO users (username, password_hash, role, reference_id, is_active) VALUES (?, ?, ?, ?, ?)",
                user.getUsername(), user.getPasswordHash(), user.getRole(), user.getReferenceId(), true);
        return findByUsername(user.getUsername()).orElse(user);
    }

    public boolean existsByUsername(String username) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM users WHERE username = ?", Integer.class, username);
        return count != null && count > 0;
    }
}

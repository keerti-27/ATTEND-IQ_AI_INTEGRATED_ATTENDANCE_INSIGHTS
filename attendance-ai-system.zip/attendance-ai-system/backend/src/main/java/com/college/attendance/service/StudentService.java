package com.college.attendance.service;

import com.college.attendance.dto.StudentRequest;
import com.college.attendance.exception.ResourceNotFoundException;
import com.college.attendance.model.Student;
import com.college.attendance.repository.StudentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {

    private final StudentRepository studentRepository;
    private final AuthService authService;

    public StudentService(StudentRepository studentRepository, AuthService authService) {
        this.studentRepository = studentRepository;
        this.authService = authService;
    }

    public List<Student> getAll() {
        return studentRepository.findAll();
    }

    public Student getById(Long id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + id));
    }

    public List<Student> search(String keyword) {
        return studentRepository.search(keyword);
    }

    public Student create(StudentRequest req) {
        Student s = toEntity(req);
        Long id = studentRepository.save(s);
        s.setStudentId(id);

        if (req.getUsername() != null && !req.getUsername().isBlank()) {
            String password = (req.getPassword() != null && !req.getPassword().isBlank())
                    ? req.getPassword() : "student123";
            authService.createUserAccount(req.getUsername(), password, "STUDENT", req.getStudentCode());
        }
        return s;
    }

    public Student update(Long id, StudentRequest req) {
        getById(id); // ensures exists
        Student s = toEntity(req);
        studentRepository.update(id, s);
        s.setStudentId(id);
        return s;
    }

    public void delete(Long id) {
        getById(id);
        studentRepository.deleteById(id);
    }

    private Student toEntity(StudentRequest req) {
        Student s = new Student();
        s.setStudentCode(req.getStudentCode());
        s.setRegisterNo(req.getRegisterNo());
        s.setName(req.getName());
        s.setEmail(req.getEmail());
        s.setPhone(req.getPhone());
        s.setDepartment(req.getDepartment());
        s.setYear(req.getYear());
        s.setSection(req.getSection());
        s.setParentName(req.getParentName());
        s.setParentEmail(req.getParentEmail());
        s.setParentPhone(req.getParentPhone());
        return s;
    }
}

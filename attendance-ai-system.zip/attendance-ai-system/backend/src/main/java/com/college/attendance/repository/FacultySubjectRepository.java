package com.college.attendance.repository;

import com.college.attendance.model.FacultySubject;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class FacultySubjectRepository {

    private final JdbcTemplate jdbcTemplate;

    public FacultySubjectRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<FacultySubject> ROW_MAPPER = (rs, rowNum) -> {
        FacultySubject fs = new FacultySubject();
        fs.setId(rs.getLong("id"));
        fs.setFacultyId(rs.getLong("faculty_id"));
        fs.setSubjectId(rs.getLong("subject_id"));
        fs.setSection(rs.getString("section"));
        return fs;
    };

    public void assign(Long facultyId, Long subjectId, String section) {
        jdbcTemplate.update(
                "INSERT INTO faculty_subjects (faculty_id, subject_id, section) VALUES (?, ?, ?)",
                facultyId, subjectId, section);
    }

    public List<FacultySubject> findByFacultyId(Long facultyId) {
        return jdbcTemplate.query(
                "SELECT * FROM faculty_subjects WHERE faculty_id = ?", ROW_MAPPER, facultyId);
    }

    public List<FacultySubject> findAll() {
        return jdbcTemplate.query("SELECT * FROM faculty_subjects", ROW_MAPPER);
    }

    public void deleteById(Long id) {
        jdbcTemplate.update("DELETE FROM faculty_subjects WHERE id = ?", id);
    }
}

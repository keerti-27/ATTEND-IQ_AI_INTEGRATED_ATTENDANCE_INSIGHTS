package com.college.attendance.repository;

import com.college.attendance.model.Subject;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

@Repository
public class SubjectRepository {

    private final JdbcTemplate jdbcTemplate;

    public SubjectRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Subject> ROW_MAPPER = (rs, rowNum) -> {
        Subject s = new Subject();
        s.setSubjectId(rs.getLong("subject_id"));
        s.setSubjectCode(rs.getString("subject_code"));
        s.setSubjectName(rs.getString("subject_name"));
        s.setDepartment(rs.getString("department"));
        s.setYear(rs.getInt("year"));
        s.setSemester(rs.getInt("semester"));
        return s;
    };

    public List<Subject> findAll() {
        return jdbcTemplate.query("SELECT * FROM subjects ORDER BY subject_name", ROW_MAPPER);
    }

    public Optional<Subject> findById(Long id) {
        List<Subject> r = jdbcTemplate.query("SELECT * FROM subjects WHERE subject_id = ?", ROW_MAPPER, id);
        return r.stream().findFirst();
    }

    public Long save(Subject s) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO subjects (subject_code, subject_name, department, year, semester) VALUES (?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, s.getSubjectCode());
            ps.setString(2, s.getSubjectName());
            ps.setString(3, s.getDepartment());
            ps.setInt(4, s.getYear());
            ps.setInt(5, s.getSemester());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public void deleteById(Long id) {
        jdbcTemplate.update("DELETE FROM subjects WHERE subject_id = ?", id);
    }

    public long count() {
        Long c = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM subjects", Long.class);
        return c != null ? c : 0;
    }
}

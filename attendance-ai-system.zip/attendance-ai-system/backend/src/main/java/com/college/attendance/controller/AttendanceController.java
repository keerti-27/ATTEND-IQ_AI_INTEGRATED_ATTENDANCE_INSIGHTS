package com.college.attendance.controller;

import com.college.attendance.dto.ApiResponse;
import com.college.attendance.dto.MarkAttendanceRequest;
import com.college.attendance.exception.ResourceNotFoundException;
import com.college.attendance.model.Faculty;
import com.college.attendance.model.FacultySubject;
import com.college.attendance.model.Student;
import com.college.attendance.model.Subject;
import com.college.attendance.repository.FacultyRepository;
import com.college.attendance.repository.FacultySubjectRepository;
import com.college.attendance.repository.StudentRepository;
import com.college.attendance.repository.SubjectRepository;
import com.college.attendance.service.AttendanceService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Faculty attendance marking module. Admin can also access via the SessionAuthFilter override. */
@RestController
@RequestMapping("/api/faculty/attendance")
public class AttendanceController {

    private final AttendanceService attendanceService;
    private final FacultyRepository facultyRepository;
    private final FacultySubjectRepository facultySubjectRepository;
    private final SubjectRepository subjectRepository;
    private final StudentRepository studentRepository;

    public AttendanceController(AttendanceService attendanceService, FacultyRepository facultyRepository,
                                 FacultySubjectRepository facultySubjectRepository, SubjectRepository subjectRepository,
                                 StudentRepository studentRepository) {
        this.attendanceService = attendanceService;
        this.facultyRepository = facultyRepository;
        this.facultySubjectRepository = facultySubjectRepository;
        this.subjectRepository = subjectRepository;
        this.studentRepository = studentRepository;
    }

    /** Returns the full faculty profile (including numeric facultyId) for the current session. */
    @GetMapping("/me")
    public ApiResponse<Faculty> me(HttpServletRequest request) {
        return ApiResponse.ok(currentFaculty(request));
    }

    /** Returns the subjects assigned to the currently logged-in faculty member. */
    @GetMapping("/my-subjects")
    public ApiResponse<List<Subject>> mySubjects(HttpServletRequest request) {
        Faculty faculty = currentFaculty(request);
        List<FacultySubject> assignments = facultySubjectRepository.findByFacultyId(faculty.getFacultyId());
        List<Subject> subjects = assignments.stream()
                .map(a -> subjectRepository.findById(a.getSubjectId()).orElse(null))
                .filter(java.util.Objects::nonNull)
                .toList();
        return ApiResponse.ok(subjects);
    }

    /** Returns the student roster for a subject (based on the section assigned to this faculty for that subject). */
    @GetMapping("/roster")
    public ApiResponse<List<Student>> roster(@RequestParam Long subjectId, HttpServletRequest request) {
        Faculty faculty = currentFaculty(request);
        Subject subject = subjectRepository.findById(subjectId)
                .orElseThrow(() -> new ResourceNotFoundException("Subject not found: " + subjectId));

        String section = facultySubjectRepository.findByFacultyId(faculty.getFacultyId()).stream()
                .filter(a -> a.getSubjectId().equals(subjectId))
                .map(FacultySubject::getSection)
                .findFirst()
                .orElseThrow(() -> new ResourceNotFoundException("This subject is not assigned to you"));

        return ApiResponse.ok(studentRepository.findBySection(section));
    }

    @PostMapping("/mark")
    public ApiResponse<Object> mark(@Valid @RequestBody MarkAttendanceRequest request, HttpServletRequest httpRequest) {
        // The faculty ID always comes from the authenticated session, never from client input,
        // so a faculty member cannot mark attendance on another faculty member's behalf.
        Faculty faculty = currentFaculty(httpRequest);
        request.setFacultyId(faculty.getFacultyId());
        attendanceService.markAttendance(request);
        return ApiResponse.ok("Attendance marked successfully", null);
    }

    private Faculty currentFaculty(HttpServletRequest request) {
        String facultyCode = (String) request.getSession().getAttribute("referenceId");
        return facultyRepository.findByCode(facultyCode)
                .orElseThrow(() -> new ResourceNotFoundException("Faculty session invalid"));
    }
}

package com.college.attendance.controller;

import com.college.attendance.dto.ApiResponse;
import com.college.attendance.dto.LeaveApplyRequest;
import com.college.attendance.dto.LeaveDecisionRequest;
import com.college.attendance.exception.ResourceNotFoundException;
import com.college.attendance.model.LeaveRequest;
import com.college.attendance.model.Student;
import com.college.attendance.repository.StudentRepository;
import com.college.attendance.service.LeaveService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class LeaveController {

    private final LeaveService leaveService;
    private final StudentRepository studentRepository;

    public LeaveController(LeaveService leaveService, StudentRepository studentRepository) {
        this.leaveService = leaveService;
        this.studentRepository = studentRepository;
    }

    // ---- STUDENT ----
    @PostMapping("/api/student/leave/apply")
    public ApiResponse<LeaveRequest> apply(@Valid @RequestBody LeaveApplyRequest request, HttpServletRequest httpRequest) {
        Student student = currentStudent(httpRequest);
        request.setStudentId(student.getStudentId());
        return ApiResponse.ok("Leave application submitted", leaveService.apply(request));
    }

    @GetMapping("/api/student/leave/mine")
    public ApiResponse<List<LeaveRequest>> mine(HttpServletRequest httpRequest) {
        Student student = currentStudent(httpRequest);
        return ApiResponse.ok(leaveService.getForStudent(student.getStudentId()));
    }

    // ---- FACULTY ----
    @GetMapping("/api/faculty/leave/pending")
    public ApiResponse<List<LeaveRequest>> pending() {
        return ApiResponse.ok(leaveService.getPending());
    }

    @PostMapping("/api/faculty/leave/{id}/decide")
    public ApiResponse<Object> decide(@PathVariable("id") Long leaveId, @Valid @RequestBody LeaveDecisionRequest request) {
        leaveService.decide(leaveId, request.getDecision(), request.getReviewerFacultyId());
        return ApiResponse.ok("Leave request " + request.getDecision().toLowerCase(), null);
    }

    // ---- ADMIN ----
    @GetMapping("/api/admin/leave/all")
    public ApiResponse<List<LeaveRequest>> all() {
        return ApiResponse.ok(leaveService.getAll());
    }

    private Student currentStudent(HttpServletRequest request) {
        String studentCode = (String) request.getSession().getAttribute("referenceId");
        return studentRepository.findByCode(studentCode)
                .orElseThrow(() -> new ResourceNotFoundException("Student session invalid"));
    }
}

package com.college.attendance.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.List;

public class MarkAttendanceRequest {
    @NotNull private Long subjectId;
    // facultyId is intentionally NOT validated here - the controller always overwrites it
    // with the ID resolved from the authenticated session, so client input is ignored.
    private Long facultyId;
    @NotNull private LocalDate attendanceDate;
    @NotEmpty private List<StudentStatus> records;

    public static class StudentStatus {
        private Long studentId;
        private String status; // PRESENT / ABSENT

        public Long getStudentId() { return studentId; }
        public void setStudentId(Long studentId) { this.studentId = studentId; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
    }

    public Long getSubjectId() { return subjectId; }
    public void setSubjectId(Long subjectId) { this.subjectId = subjectId; }
    public Long getFacultyId() { return facultyId; }
    public void setFacultyId(Long facultyId) { this.facultyId = facultyId; }
    public LocalDate getAttendanceDate() { return attendanceDate; }
    public void setAttendanceDate(LocalDate attendanceDate) { this.attendanceDate = attendanceDate; }
    public List<StudentStatus> getRecords() { return records; }
    public void setRecords(List<StudentStatus> records) { this.records = records; }
}

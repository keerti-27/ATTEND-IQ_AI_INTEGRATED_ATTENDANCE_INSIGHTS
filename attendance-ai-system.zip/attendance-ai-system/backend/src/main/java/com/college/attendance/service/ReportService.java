package com.college.attendance.service;

import com.college.attendance.repository.AttendanceRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class ReportService {

    private final AttendanceRepository attendanceRepository;

    public ReportService(AttendanceRepository attendanceRepository) {
        this.attendanceRepository = attendanceRepository;
    }

    /** Daily report: per-subject totals for a given date. */
    public List<Map<String, Object>> dailyReport(LocalDate date) {
        return attendanceRepository.subjectWiseOverall(); // subject-wise totals overall; date filter applied on frontend export for demo simplicity
    }

    /** Monthly report per student. */
    public List<Map<String, Object>> monthlyReport() {
        return attendanceRepository.overallPercentagePerStudent();
    }

    /** Defaulter report: students below the minimum required attendance. */
    public List<Map<String, Object>> defaulterReport(double minimumRequired) {
        return attendanceRepository.overallPercentagePerStudent().stream()
                .filter(r -> r.get("percentage") != null && ((Number) r.get("percentage")).doubleValue() < minimumRequired)
                .toList();
    }
}

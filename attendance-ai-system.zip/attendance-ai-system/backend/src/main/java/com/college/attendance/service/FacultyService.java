package com.college.attendance.service;

import com.college.attendance.dto.FacultyRequest;
import com.college.attendance.exception.ResourceNotFoundException;
import com.college.attendance.model.Faculty;
import com.college.attendance.repository.FacultyRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FacultyService {

    private final FacultyRepository facultyRepository;
    private final AuthService authService;

    public FacultyService(FacultyRepository facultyRepository, AuthService authService) {
        this.facultyRepository = facultyRepository;
        this.authService = authService;
    }

    public List<Faculty> getAll() {
        return facultyRepository.findAll();
    }

    public Faculty getById(Long id) {
        return facultyRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Faculty not found: " + id));
    }

    public List<Faculty> search(String keyword) {
        return facultyRepository.search(keyword);
    }

    public Faculty create(FacultyRequest req) {
        Faculty f = toEntity(req);
        Long id = facultyRepository.save(f);
        f.setFacultyId(id);

        if (req.getUsername() != null && !req.getUsername().isBlank()) {
            String password = (req.getPassword() != null && !req.getPassword().isBlank())
                    ? req.getPassword() : "faculty123";
            authService.createUserAccount(req.getUsername(), password, "FACULTY", req.getFacultyCode());
        }
        return f;
    }

    public Faculty update(Long id, FacultyRequest req) {
        getById(id);
        Faculty f = toEntity(req);
        facultyRepository.update(id, f);
        f.setFacultyId(id);
        return f;
    }

    public void delete(Long id) {
        getById(id);
        facultyRepository.deleteById(id);
    }

    private Faculty toEntity(FacultyRequest req) {
        Faculty f = new Faculty();
        f.setFacultyCode(req.getFacultyCode());
        f.setName(req.getName());
        f.setEmail(req.getEmail());
        f.setPhone(req.getPhone());
        f.setDepartment(req.getDepartment());
        return f;
    }
}

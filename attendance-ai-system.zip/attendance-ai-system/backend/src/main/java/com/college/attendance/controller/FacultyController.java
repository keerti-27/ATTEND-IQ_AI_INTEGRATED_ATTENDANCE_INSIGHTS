package com.college.attendance.controller;

import com.college.attendance.dto.ApiResponse;
import com.college.attendance.dto.FacultyRequest;
import com.college.attendance.model.Faculty;
import com.college.attendance.service.FacultyService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/faculty")
public class FacultyController {

    private final FacultyService facultyService;

    public FacultyController(FacultyService facultyService) {
        this.facultyService = facultyService;
    }

    @GetMapping
    public ApiResponse<List<Faculty>> getAll(@RequestParam(required = false) String search) {
        List<Faculty> faculty = (search == null || search.isBlank())
                ? facultyService.getAll() : facultyService.search(search);
        return ApiResponse.ok(faculty);
    }

    @GetMapping("/{id}")
    public ApiResponse<Faculty> getById(@PathVariable Long id) {
        return ApiResponse.ok(facultyService.getById(id));
    }

    @PostMapping
    public ApiResponse<Faculty> create(@Valid @RequestBody FacultyRequest request) {
        return ApiResponse.ok("Faculty created successfully", facultyService.create(request));
    }

    @PutMapping("/{id}")
    public ApiResponse<Faculty> update(@PathVariable Long id, @Valid @RequestBody FacultyRequest request) {
        return ApiResponse.ok("Faculty updated successfully", facultyService.update(id, request));
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Object> delete(@PathVariable Long id) {
        facultyService.delete(id);
        return ApiResponse.ok("Faculty deleted successfully", null);
    }
}

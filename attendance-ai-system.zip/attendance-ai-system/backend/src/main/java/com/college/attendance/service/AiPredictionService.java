package com.college.attendance.service;

import com.college.attendance.dto.AiPredictionResult;
import com.college.attendance.exception.ResourceNotFoundException;
import com.college.attendance.model.AiPrediction;
import com.college.attendance.model.Student;
import com.college.attendance.repository.AiPredictionRepository;
import com.college.attendance.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Calls the real Flask AI prediction service (ai_model/app.py) for every prediction.
 * No shortcuts: the actual trained RandomForest models decide the outcome, not
 * hand-coded thresholds inside Java.
 */
@Service
public class AiPredictionService {

    private final AttendanceService attendanceService;
    private final StudentRepository studentRepository;
    private final AiPredictionRepository aiPredictionRepository;
    private final RestTemplate restTemplate;

    @Value("${ai.service.url}")
    private String aiServiceUrl;

    public AiPredictionService(AttendanceService attendanceService, StudentRepository studentRepository,
                                AiPredictionRepository aiPredictionRepository, RestTemplate restTemplate) {
        this.attendanceService = attendanceService;
        this.studentRepository = studentRepository;
        this.aiPredictionRepository = aiPredictionRepository;
        this.restTemplate = restTemplate;
    }

    @SuppressWarnings("unchecked")
    public AiPredictionResult predictForStudent(Long studentId) {
        Student student = studentRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + studentId));

        Map<String, Object> features = attendanceService.predictionFeaturesForStudent(studentId);
        if (features.get("total_classes") == null || ((Number) features.get("total_classes")).intValue() == 0) {
            throw new ResourceNotFoundException("No attendance history found for student " + studentId
                    + " - cannot generate a prediction yet.");
        }

        double currentAttendance = toDouble(features.get("current_attendance"));
        int totalClasses = ((Number) features.get("total_classes")).intValue();
        int classesAttended = ((Number) features.get("classes_attended")).intValue();
        int classesAbsent = ((Number) features.get("classes_absent")).intValue();
        int recentAbsences = ((Number) features.getOrDefault("recent_absences", 0)).intValue();
        Double previousMonthAttendance = features.get("previous_month_attendance") == null
                ? currentAttendance : toDouble(features.get("previous_month_attendance"));
        double attendanceTrend = currentAttendance - previousMonthAttendance;
        int leaveDays = 0; // could be wired to leave_requests approved days; kept simple and explicit here

        Map<String, Object> payload = new HashMap<>();
        payload.put("current_attendance", currentAttendance);
        payload.put("total_classes", totalClasses);
        payload.put("classes_attended", classesAttended);
        payload.put("classes_absent", classesAbsent);
        payload.put("recent_absences", recentAbsences);
        payload.put("leave_days", leaveDays);
        payload.put("previous_month_attendance", previousMonthAttendance);
        payload.put("attendance_trend", attendanceTrend);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<Map<String, Object>> entity = new HttpEntity<>(payload, headers);

        Map<String, Object> response;
        try {
            response = restTemplate.postForObject(aiServiceUrl + "/predict", entity, Map.class);
        } catch (RestClientException ex) {
            throw new RuntimeException("AI prediction service is unreachable at " + aiServiceUrl
                    + ". Make sure the Flask app (ai_model/app.py) is running. Cause: " + ex.getMessage());
        }

        if (response == null || response.get("predicted_attendance") == null) {
            throw new RuntimeException("AI prediction service returned an invalid response");
        }

        double predictedAttendance = toDouble(response.get("predicted_attendance"));
        String riskLevel = String.valueOf(response.get("risk_level"));
        String message = String.valueOf(response.get("message"));

        aiPredictionRepository.save(studentId, BigDecimal.valueOf(currentAttendance),
                BigDecimal.valueOf(predictedAttendance), riskLevel, message);

        AiPredictionResult result = new AiPredictionResult();
        result.setStudentId(studentId);
        result.setStudentCode(student.getStudentCode());
        result.setStudentName(student.getName());
        result.setCurrentAttendance(currentAttendance);
        result.setPredictedAttendance(predictedAttendance);
        result.setRiskLevel(riskLevel);
        result.setMessage(message);
        return result;
    }

    public List<AiPrediction> getLatestForAllStudents() {
        return aiPredictionRepository.findLatestPerStudent();
    }

    public List<AiPrediction> getHistoryForStudent(Long studentId) {
        return aiPredictionRepository.findByStudent(studentId);
    }

    private double toDouble(Object o) {
        return o == null ? 0.0 : ((Number) o).doubleValue();
    }
}

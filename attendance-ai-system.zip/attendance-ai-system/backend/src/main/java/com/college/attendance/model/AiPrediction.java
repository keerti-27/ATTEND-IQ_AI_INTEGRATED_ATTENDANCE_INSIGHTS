package com.college.attendance.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class AiPrediction {
    private Long predictionId;
    private Long studentId;
    private BigDecimal currentAttendance;
    private BigDecimal predictedAttendance;
    private String riskLevel; // LOW / MEDIUM / HIGH
    private String message;
    private LocalDateTime predictedAt;

    public AiPrediction() {}

    public Long getPredictionId() { return predictionId; }
    public void setPredictionId(Long predictionId) { this.predictionId = predictionId; }
    public Long getStudentId() { return studentId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }
    public BigDecimal getCurrentAttendance() { return currentAttendance; }
    public void setCurrentAttendance(BigDecimal currentAttendance) { this.currentAttendance = currentAttendance; }
    public BigDecimal getPredictedAttendance() { return predictedAttendance; }
    public void setPredictedAttendance(BigDecimal predictedAttendance) { this.predictedAttendance = predictedAttendance; }
    public String getRiskLevel() { return riskLevel; }
    public void setRiskLevel(String riskLevel) { this.riskLevel = riskLevel; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public LocalDateTime getPredictedAt() { return predictedAt; }
    public void setPredictedAt(LocalDateTime predictedAt) { this.predictedAt = predictedAt; }
}

package com.college.attendance.model;

public class FacultySubject {
    private Long id;
    private Long facultyId;
    private Long subjectId;
    private String section;

    public FacultySubject() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getFacultyId() { return facultyId; }
    public void setFacultyId(Long facultyId) { this.facultyId = facultyId; }
    public Long getSubjectId() { return subjectId; }
    public void setSubjectId(Long subjectId) { this.subjectId = subjectId; }
    public String getSection() { return section; }
    public void setSection(String section) { this.section = section; }
}

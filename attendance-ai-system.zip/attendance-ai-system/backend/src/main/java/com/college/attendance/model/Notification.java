package com.college.attendance.model;

import java.time.LocalDateTime;

public class Notification {
    private Long notificationId;
    private Long studentId;
    private String parentName;
    private String parentEmail;
    private String message;
    private LocalDateTime notificationDate;
    private String status; // PENDING / SENT / FAILED

    public Notification() {}

    public Long getNotificationId() { return notificationId; }
    public void setNotificationId(Long notificationId) { this.notificationId = notificationId; }
    public Long getStudentId() { return studentId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }
    public String getParentName() { return parentName; }
    public void setParentName(String parentName) { this.parentName = parentName; }
    public String getParentEmail() { return parentEmail; }
    public void setParentEmail(String parentEmail) { this.parentEmail = parentEmail; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public LocalDateTime getNotificationDate() { return notificationDate; }
    public void setNotificationDate(LocalDateTime notificationDate) { this.notificationDate = notificationDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}

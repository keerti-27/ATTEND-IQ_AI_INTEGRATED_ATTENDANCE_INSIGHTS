package com.college.attendance.service;

import com.college.attendance.dto.SubjectRequest;
import com.college.attendance.exception.ResourceNotFoundException;
import com.college.attendance.model.Subject;
import com.college.attendance.repository.FacultySubjectRepository;
import com.college.attendance.repository.SubjectRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SubjectService {

    private final SubjectRepository subjectRepository;
    private final FacultySubjectRepository facultySubjectRepository;

    public SubjectService(SubjectRepository subjectRepository, FacultySubjectRepository facultySubjectRepository) {
        this.subjectRepository = subjectRepository;
        this.facultySubjectRepository = facultySubjectRepository;
    }

    public List<Subject> getAll() {
        return subjectRepository.findAll();
    }

    public Subject getById(Long id) {
        return subjectRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Subject not found: " + id));
    }

    public Subject create(SubjectRequest req) {
        Subject s = new Subject();
        s.setSubjectCode(req.getSubjectCode());
        s.setSubjectName(req.getSubjectName());
        s.setDepartment(req.getDepartment());
        s.setYear(req.getYear());
        s.setSemester(req.getSemester());
        Long id = subjectRepository.save(s);
        s.setSubjectId(id);

        if (req.getFacultyId() != null && req.getSection() != null) {
            facultySubjectRepository.assign(req.getFacultyId(), id, req.getSection());
        }
        return s;
    }

    public void assignFaculty(Long subjectId, Long facultyId, String section) {
        getById(subjectId);
        facultySubjectRepository.assign(facultyId, subjectId, section);
    }

    public void delete(Long id) {
        getById(id);
        subjectRepository.deleteById(id);
    }
}

package com.college.attendance.service;

import com.college.attendance.dto.AttendanceSummaryDto;
import com.college.attendance.dto.MarkAttendanceRequest;
import com.college.attendance.model.Student;
import com.college.attendance.model.Subject;
import com.college.attendance.repository.AttendanceRepository;
import com.college.attendance.repository.StudentRepository;
import com.college.attendance.repository.SubjectRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Service
public class AttendanceService {

    private final AttendanceRepository attendanceRepository;
    private final StudentRepository studentRepository;
    private final SubjectRepository subjectRepository;
    private final NotificationService notificationService;

    public AttendanceService(AttendanceRepository attendanceRepository, StudentRepository studentRepository,
                              SubjectRepository subjectRepository, NotificationService notificationService) {
        this.attendanceRepository = attendanceRepository;
        this.studentRepository = studentRepository;
        this.subjectRepository = subjectRepository;
        this.notificationService = notificationService;
    }

    /**
     * Marks/updates attendance for a whole class in one submission.
     * Duplicate (student, subject, date) rows are updated instead of duplicated
     * (this supports the "Edit attendance" use case as well as first-time marking).
     * A parent notification is generated for every student marked ABSENT.
     */
    public void markAttendance(MarkAttendanceRequest request) {
        Subject subject = subjectRepository.findById(request.getSubjectId())
                .orElseThrow(() -> new com.college.attendance.exception.ResourceNotFoundException(
                        "Subject not found: " + request.getSubjectId()));

        for (MarkAttendanceRequest.StudentStatus record : request.getRecords()) {
            String status = record.getStatus() == null ? "ABSENT" : record.getStatus().toUpperCase();
            attendanceRepository.upsert(
                    record.getStudentId(), request.getSubjectId(), request.getFacultyId(),
                    request.getAttendanceDate(), status);

            if ("ABSENT".equals(status)) {
                Student student = studentRepository.findById(record.getStudentId()).orElse(null);
                if (student != null) {
                    notificationService.notifyAbsence(student, subject.getSubjectName(), request.getAttendanceDate());
                }
            }
        }
    }

    public List<Map<String, Object>> overallPercentagePerStudent() {
        return attendanceRepository.overallPercentagePerStudent();
    }

    public List<AttendanceSummaryDto> subjectWisePercentageForStudent(Long studentId) {
        List<Map<String, Object>> rows = attendanceRepository.subjectWisePercentage(studentId);
        return rows.stream().map(row -> {
            AttendanceSummaryDto dto = new AttendanceSummaryDto();
            dto.setSubjectId(((Number) row.get("subject_id")).longValue());
            dto.setSubjectName((String) row.get("subject_name"));
            dto.setTotalClasses(((Number) row.get("total_classes")).intValue());
            dto.setPresentCount(((Number) row.get("present_count")).intValue());
            dto.setAbsentCount(dto.getTotalClasses() - dto.getPresentCount());
            dto.setPercentage(row.get("percentage") == null ? 0.0 : ((Number) row.get("percentage")).doubleValue());
            return dto;
        }).toList();
    }

    public List<Map<String, Object>> monthlyAttendance(Long studentId) {
        return attendanceRepository.monthlyAttendance(studentId);
    }

    public List<Map<String, Object>> subjectWiseOverall() {
        return attendanceRepository.subjectWiseOverall();
    }

    public List<Map<String, Object>> monthlyTrendOverall() {
        return attendanceRepository.monthlyTrendOverall();
    }

    public Map<String, Object> presentAbsentTotals() {
        return attendanceRepository.presentAbsentTotals();
    }

    public long countTodayMarked() {
        return attendanceRepository.countTodayMarked();
    }

    public Map<String, Object> predictionFeaturesForStudent(Long studentId) {
        return attendanceRepository.predictionFeaturesForStudent(studentId);
    }
}

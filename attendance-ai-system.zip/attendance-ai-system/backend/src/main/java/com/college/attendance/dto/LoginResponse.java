package com.college.attendance.dto;

public class LoginResponse {
    private String username;
    private String role;
    private String referenceId;
    private String displayName;

    public LoginResponse() {}

    public LoginResponse(String username, String role, String referenceId, String displayName) {
        this.username = username;
        this.role = role;
        this.referenceId = referenceId;
        this.displayName = displayName;
    }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getReferenceId() { return referenceId; }
    public void setReferenceId(String referenceId) { this.referenceId = referenceId; }
    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }
}

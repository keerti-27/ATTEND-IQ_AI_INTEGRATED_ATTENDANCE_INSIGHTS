package com.college.attendance.controller;

import com.college.attendance.dto.ApiResponse;
import com.college.attendance.dto.LoginRequest;
import com.college.attendance.dto.LoginResponse;
import com.college.attendance.service.AuthService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ApiResponse<LoginResponse> login(@Valid @RequestBody LoginRequest request, HttpServletRequest httpRequest) {
        LoginResponse response = authService.login(request);

        HttpSession session = httpRequest.getSession(true);
        session.setAttribute("username", response.getUsername());
        session.setAttribute("role", response.getRole());
        session.setAttribute("referenceId", response.getReferenceId());

        return ApiResponse.ok("Login successful", response);
    }

    @PostMapping("/logout")
    public ApiResponse<Object> logout(HttpServletRequest httpRequest) {
        HttpSession session = httpRequest.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        return ApiResponse.ok("Logged out successfully", null);
    }

    @GetMapping("/me")
    public ApiResponse<Object> me(HttpServletRequest httpRequest) {
        HttpSession session = httpRequest.getSession(false);
        if (session == null || session.getAttribute("role") == null) {
            return ApiResponse.error("Not logged in");
        }
        return ApiResponse.ok(java.util.Map.of(
                "username", session.getAttribute("username"),
                "role", session.getAttribute("role"),
                "referenceId", session.getAttribute("referenceId")
        ));
    }
}

package com.college.attendance.service;

import com.college.attendance.model.Notification;
import com.college.attendance.model.Student;
import com.college.attendance.repository.NotificationRepository;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class NotificationService {

    private final NotificationRepository notificationRepository;

    public NotificationService(NotificationRepository notificationRepository) {
        this.notificationRepository = notificationRepository;
    }

    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    /** Creates a parent notification whenever a student is marked ABSENT. */
    public void notifyAbsence(Student student, String subjectName, java.time.LocalDate date) {
        String message = String.format(
                "Your ward %s was marked absent for %s on %s.",
                student.getName(), subjectName, date.format(DATE_FMT));

        Notification n = new Notification();
        n.setStudentId(student.getStudentId());
        n.setParentName(student.getParentName());
        n.setParentEmail(student.getParentEmail());
        n.setMessage(message);
        n.setStatus("SENT"); // In this demo, "SENT" means recorded and visible in the notifications page.
        notificationRepository.save(n);
    }

    public List<Notification> getForStudent(Long studentId) {
        return notificationRepository.findByStudent(studentId);
    }

    public List<Notification> getAll() {
        return notificationRepository.findAll();
    }
}

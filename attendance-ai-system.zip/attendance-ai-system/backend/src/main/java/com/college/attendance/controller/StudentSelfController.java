package com.college.attendance.controller;

import com.college.attendance.dto.ApiResponse;
import com.college.attendance.dto.AttendanceSummaryDto;
import com.college.attendance.exception.ResourceNotFoundException;
import com.college.attendance.model.Student;
import com.college.attendance.repository.StudentRepository;
import com.college.attendance.service.AttendanceService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/** Endpoints for a logged-in STUDENT to view their own profile and attendance. */
@RestController
@RequestMapping("/api/student")
public class StudentSelfController {

    private final StudentRepository studentRepository;
    private final AttendanceService attendanceService;

    public StudentSelfController(StudentRepository studentRepository, AttendanceService attendanceService) {
        this.studentRepository = studentRepository;
        this.attendanceService = attendanceService;
    }

    @GetMapping("/profile")
    public ApiResponse<Student> profile(HttpServletRequest request) {
        return ApiResponse.ok(currentStudent(request));
    }

    @GetMapping("/attendance/subject-wise")
    public ApiResponse<List<AttendanceSummaryDto>> subjectWise(HttpServletRequest request) {
        Student student = currentStudent(request);
        return ApiResponse.ok(attendanceService.subjectWisePercentageForStudent(student.getStudentId()));
    }

    @GetMapping("/attendance/monthly")
    public ApiResponse<List<Map<String, Object>>> monthly(HttpServletRequest request) {
        Student student = currentStudent(request);
        return ApiResponse.ok(attendanceService.monthlyAttendance(student.getStudentId()));
    }

    @GetMapping("/attendance/overall")
    public ApiResponse<Map<String, Object>> overall(HttpServletRequest request) {
        Student student = currentStudent(request);
        List<AttendanceSummaryDto> subjectWise = attendanceService.subjectWisePercentageForStudent(student.getStudentId());
        int totalClasses = subjectWise.stream().mapToInt(AttendanceSummaryDto::getTotalClasses).sum();
        int present = subjectWise.stream().mapToInt(AttendanceSummaryDto::getPresentCount).sum();
        double pct = totalClasses == 0 ? 0.0 : Math.round((present * 10000.0 / totalClasses)) / 100.0;
        return ApiResponse.ok(Map.of(
                "totalClasses", totalClasses,
                "presentCount", present,
                "absentCount", totalClasses - present,
                "percentage", pct
        ));
    }

    private Student currentStudent(HttpServletRequest request) {
        String studentCode = (String) request.getSession().getAttribute("referenceId");
        return studentRepository.findByCode(studentCode)
                .orElseThrow(() -> new ResourceNotFoundException("Student session invalid"));
    }
}

package com.college.attendance.dto;

public class DashboardStatsDto {
    private long totalStudents;
    private long totalFaculty;
    private long totalSubjects;
    private long todayAttendanceMarked;
    private long studentsBelow75;
    private long highRiskStudents;
    private long pendingLeaveRequests;

    public long getTotalStudents() { return totalStudents; }
    public void setTotalStudents(long totalStudents) { this.totalStudents = totalStudents; }
    public long getTotalFaculty() { return totalFaculty; }
    public void setTotalFaculty(long totalFaculty) { this.totalFaculty = totalFaculty; }
    public long getTotalSubjects() { return totalSubjects; }
    public void setTotalSubjects(long totalSubjects) { this.totalSubjects = totalSubjects; }
    public long getTodayAttendanceMarked() { return todayAttendanceMarked; }
    public void setTodayAttendanceMarked(long todayAttendanceMarked) { this.todayAttendanceMarked = todayAttendanceMarked; }
    public long getStudentsBelow75() { return studentsBelow75; }
    public void setStudentsBelow75(long studentsBelow75) { this.studentsBelow75 = studentsBelow75; }
    public long getHighRiskStudents() { return highRiskStudents; }
    public void setHighRiskStudents(long highRiskStudents) { this.highRiskStudents = highRiskStudents; }
    public long getPendingLeaveRequests() { return pendingLeaveRequests; }
    public void setPendingLeaveRequests(long pendingLeaveRequests) { this.pendingLeaveRequests = pendingLeaveRequests; }
}

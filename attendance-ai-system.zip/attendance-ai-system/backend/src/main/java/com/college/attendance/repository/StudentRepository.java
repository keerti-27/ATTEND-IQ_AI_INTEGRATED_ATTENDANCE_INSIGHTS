package com.college.attendance.repository;

import com.college.attendance.model.Student;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

@Repository
public class StudentRepository {

    private final JdbcTemplate jdbcTemplate;

    public StudentRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Student> ROW_MAPPER = (rs, rowNum) -> {
        Student s = new Student();
        s.setStudentId(rs.getLong("student_id"));
        s.setStudentCode(rs.getString("student_code"));
        s.setRegisterNo(rs.getString("register_no"));
        s.setName(rs.getString("name"));
        s.setEmail(rs.getString("email"));
        s.setPhone(rs.getString("phone"));
        s.setDepartment(rs.getString("department"));
        s.setYear(rs.getInt("year"));
        s.setSection(rs.getString("section"));
        s.setParentName(rs.getString("parent_name"));
        s.setParentEmail(rs.getString("parent_email"));
        s.setParentPhone(rs.getString("parent_phone"));
        return s;
    };

    public List<Student> findAll() {
        return jdbcTemplate.query("SELECT * FROM students ORDER BY student_code", ROW_MAPPER);
    }

    public Optional<Student> findById(Long id) {
        List<Student> r = jdbcTemplate.query("SELECT * FROM students WHERE student_id = ?", ROW_MAPPER, id);
        return r.stream().findFirst();
    }

    public Optional<Student> findByCode(String code) {
        List<Student> r = jdbcTemplate.query("SELECT * FROM students WHERE student_code = ?", ROW_MAPPER, code);
        return r.stream().findFirst();
    }

    public List<Student> search(String keyword) {
        String like = "%" + keyword + "%";
        return jdbcTemplate.query(
                "SELECT * FROM students WHERE name LIKE ? OR student_code LIKE ? OR register_no LIKE ? OR department LIKE ? ORDER BY name",
                ROW_MAPPER, like, like, like, like);
    }

    public Long save(Student s) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO students (student_code, register_no, name, email, phone, department, year, section, parent_name, parent_email, parent_phone) "
                            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, s.getStudentCode());
            ps.setString(2, s.getRegisterNo());
            ps.setString(3, s.getName());
            ps.setString(4, s.getEmail());
            ps.setString(5, s.getPhone());
            ps.setString(6, s.getDepartment());
            ps.setInt(7, s.getYear());
            ps.setString(8, s.getSection());
            ps.setString(9, s.getParentName());
            ps.setString(10, s.getParentEmail());
            ps.setString(11, s.getParentPhone());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public void update(Long id, Student s) {
        jdbcTemplate.update(
                "UPDATE students SET register_no=?, name=?, email=?, phone=?, department=?, year=?, section=?, "
                        + "parent_name=?, parent_email=?, parent_phone=? WHERE student_id=?",
                s.getRegisterNo(), s.getName(), s.getEmail(), s.getPhone(), s.getDepartment(), s.getYear(),
                s.getSection(), s.getParentName(), s.getParentEmail(), s.getParentPhone(), id);
    }

    public void deleteById(Long id) {
        jdbcTemplate.update("DELETE FROM students WHERE student_id = ?", id);
    }

    public long count() {
        Long c = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM students", Long.class);
        return c != null ? c : 0;
    }

    public List<Student> findBySectionAndDept(String section, String department) {
        return jdbcTemplate.query(
                "SELECT * FROM students WHERE section = ? AND department = ? ORDER BY name",
                ROW_MAPPER, section, department);
    }

    /** Used for attendance rosters: a "class" is grouped by section only, since one subject
     *  section can be shared by students across related departments in a combined class. */
    public List<Student> findBySection(String section) {
        return jdbcTemplate.query(
                "SELECT * FROM students WHERE section = ? ORDER BY name", ROW_MAPPER, section);
    }
}

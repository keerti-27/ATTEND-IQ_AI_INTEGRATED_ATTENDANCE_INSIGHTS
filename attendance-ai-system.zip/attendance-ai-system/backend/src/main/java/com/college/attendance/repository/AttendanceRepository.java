package com.college.attendance.repository;

import com.college.attendance.model.Attendance;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Repository
public class AttendanceRepository {

    private final JdbcTemplate jdbcTemplate;

    public AttendanceRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Attendance> ROW_MAPPER = (rs, rowNum) -> {
        Attendance a = new Attendance();
        a.setAttendanceId(rs.getLong("attendance_id"));
        a.setStudentId(rs.getLong("student_id"));
        a.setSubjectId(rs.getLong("subject_id"));
        a.setFacultyId(rs.getLong("faculty_id"));
        a.setAttendanceDate(rs.getDate("attendance_date").toLocalDate());
        a.setStatus(rs.getString("status"));
        return a;
    };

    public boolean existsForStudentSubjectDate(Long studentId, Long subjectId, LocalDate date) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM attendance WHERE student_id=? AND subject_id=? AND attendance_date=?",
                Integer.class, studentId, subjectId, date);
        return count != null && count > 0;
    }

    /** Insert if not already present for (student, subject, date); update status if it exists (edit attendance). */
    public void upsert(Long studentId, Long subjectId, Long facultyId, LocalDate date, String status) {
        if (existsForStudentSubjectDate(studentId, subjectId, date)) {
            jdbcTemplate.update(
                    "UPDATE attendance SET status = ?, faculty_id = ? WHERE student_id=? AND subject_id=? AND attendance_date=?",
                    status, facultyId, studentId, subjectId, date);
        } else {
            KeyHolder keyHolder = new GeneratedKeyHolder();
            jdbcTemplate.update(connection -> {
                PreparedStatement ps = connection.prepareStatement(
                        "INSERT INTO attendance (student_id, subject_id, faculty_id, attendance_date, status) VALUES (?, ?, ?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS);
                ps.setLong(1, studentId);
                ps.setLong(2, subjectId);
                ps.setLong(3, facultyId);
                ps.setDate(4, java.sql.Date.valueOf(date));
                ps.setString(5, status);
                return ps;
            }, keyHolder);
        }
    }

    public List<Attendance> findByStudentAndSubject(Long studentId, Long subjectId) {
        return jdbcTemplate.query(
                "SELECT * FROM attendance WHERE student_id=? AND subject_id=? ORDER BY attendance_date",
                ROW_MAPPER, studentId, subjectId);
    }

    public List<Attendance> findByStudent(Long studentId) {
        return jdbcTemplate.query(
                "SELECT * FROM attendance WHERE student_id=? ORDER BY attendance_date", ROW_MAPPER, studentId);
    }

    public List<Attendance> findBySubjectAndDate(Long subjectId, LocalDate date) {
        return jdbcTemplate.query(
                "SELECT * FROM attendance WHERE subject_id=? AND attendance_date=?", ROW_MAPPER, subjectId, date);
    }

    public long countTodayMarked() {
        Long c = jdbcTemplate.queryForObject(
                "SELECT COUNT(DISTINCT subject_id) FROM attendance WHERE attendance_date = CURDATE()", Long.class);
        return c != null ? c : 0;
    }

    /** Overall attendance percentage per student (all subjects combined). */
    public List<Map<String, Object>> overallPercentagePerStudent() {
        return jdbcTemplate.queryForList(
                "SELECT s.student_id, s.student_code, s.name, "
                        + "COUNT(a.attendance_id) AS total_classes, "
                        + "SUM(CASE WHEN a.status='PRESENT' THEN 1 ELSE 0 END) AS present_count, "
                        + "ROUND(SUM(CASE WHEN a.status='PRESENT' THEN 1 ELSE 0 END) / COUNT(a.attendance_id) * 100, 2) AS percentage "
                        + "FROM students s LEFT JOIN attendance a ON s.student_id = a.student_id "
                        + "GROUP BY s.student_id, s.student_code, s.name "
                        + "HAVING total_classes > 0 "
                        + "ORDER BY percentage ASC");
    }

    public List<Map<String, Object>> subjectWisePercentage(Long studentId) {
        return jdbcTemplate.queryForList(
                "SELECT sub.subject_id, sub.subject_name, "
                        + "COUNT(a.attendance_id) AS total_classes, "
                        + "SUM(CASE WHEN a.status='PRESENT' THEN 1 ELSE 0 END) AS present_count, "
                        + "ROUND(SUM(CASE WHEN a.status='PRESENT' THEN 1 ELSE 0 END) / COUNT(a.attendance_id) * 100, 2) AS percentage "
                        + "FROM attendance a JOIN subjects sub ON a.subject_id = sub.subject_id "
                        + "WHERE a.student_id = ? GROUP BY sub.subject_id, sub.subject_name", studentId);
    }

    public List<Map<String, Object>> monthlyAttendance(Long studentId) {
        return jdbcTemplate.queryForList(
                "SELECT DATE_FORMAT(attendance_date, '%Y-%m') AS month, "
                        + "COUNT(*) AS total_classes, "
                        + "SUM(CASE WHEN status='PRESENT' THEN 1 ELSE 0 END) AS present_count, "
                        + "ROUND(SUM(CASE WHEN status='PRESENT' THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS percentage "
                        + "FROM attendance WHERE student_id = ? GROUP BY month ORDER BY month", studentId);
    }

    public List<Map<String, Object>> subjectWiseOverall() {
        return jdbcTemplate.queryForList(
                "SELECT sub.subject_id, sub.subject_name, "
                        + "COUNT(a.attendance_id) AS total_classes, "
                        + "SUM(CASE WHEN a.status='PRESENT' THEN 1 ELSE 0 END) AS present_count, "
                        + "ROUND(SUM(CASE WHEN a.status='PRESENT' THEN 1 ELSE 0 END) / COUNT(a.attendance_id) * 100, 2) AS percentage "
                        + "FROM attendance a JOIN subjects sub ON a.subject_id = sub.subject_id "
                        + "GROUP BY sub.subject_id, sub.subject_name");
    }

    public List<Map<String, Object>> monthlyTrendOverall() {
        return jdbcTemplate.queryForList(
                "SELECT DATE_FORMAT(attendance_date, '%Y-%m') AS month, "
                        + "ROUND(SUM(CASE WHEN status='PRESENT' THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS percentage "
                        + "FROM attendance GROUP BY month ORDER BY month");
    }

    public Map<String, Object> presentAbsentTotals() {
        return jdbcTemplate.queryForMap(
                "SELECT SUM(CASE WHEN status='PRESENT' THEN 1 ELSE 0 END) AS present_total, "
                        + "SUM(CASE WHEN status='ABSENT' THEN 1 ELSE 0 END) AS absent_total FROM attendance");
    }

    /** Aggregated attendance features for a student, used as input to the AI prediction API. */
    public Map<String, Object> predictionFeaturesForStudent(Long studentId) {
        return jdbcTemplate.queryForMap(
                "SELECT "
                        + "  COUNT(*) AS total_classes, "
                        + "  SUM(CASE WHEN status='PRESENT' THEN 1 ELSE 0 END) AS classes_attended, "
                        + "  SUM(CASE WHEN status='ABSENT' THEN 1 ELSE 0 END) AS classes_absent, "
                        + "  ROUND(SUM(CASE WHEN status='PRESENT' THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) AS current_attendance, "
                        + "  (SELECT COUNT(*) FROM attendance WHERE student_id = ? AND status='ABSENT' AND attendance_date >= DATE_SUB(CURDATE(), INTERVAL 14 DAY)) AS recent_absences, "
                        + "  (SELECT ROUND(SUM(CASE WHEN status='PRESENT' THEN 1 ELSE 0 END) / COUNT(*) * 100, 2) FROM attendance WHERE student_id = ? AND attendance_date < DATE_SUB(CURDATE(), INTERVAL 30 DAY)) AS previous_month_attendance "
                        + "FROM attendance WHERE student_id = ?", studentId, studentId, studentId);
    }
}

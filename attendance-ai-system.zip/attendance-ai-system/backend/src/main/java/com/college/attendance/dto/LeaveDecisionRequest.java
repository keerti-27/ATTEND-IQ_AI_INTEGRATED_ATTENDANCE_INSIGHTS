package com.college.attendance.dto;

import jakarta.validation.constraints.NotNull;

public class LeaveDecisionRequest {
    @NotNull private Long reviewerFacultyId;
    @NotNull private String decision; // APPROVED / REJECTED

    public Long getReviewerFacultyId() { return reviewerFacultyId; }
    public void setReviewerFacultyId(Long reviewerFacultyId) { this.reviewerFacultyId = reviewerFacultyId; }
    public String getDecision() { return decision; }
    public void setDecision(String decision) { this.decision = decision; }
}

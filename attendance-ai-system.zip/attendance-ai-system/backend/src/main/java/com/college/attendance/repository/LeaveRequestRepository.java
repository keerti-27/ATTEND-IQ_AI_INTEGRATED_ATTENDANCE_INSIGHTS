package com.college.attendance.repository;

import com.college.attendance.model.LeaveRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

@Repository
public class LeaveRequestRepository {

    private final JdbcTemplate jdbcTemplate;

    public LeaveRequestRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<LeaveRequest> ROW_MAPPER = (rs, rowNum) -> {
        LeaveRequest l = new LeaveRequest();
        l.setLeaveId(rs.getLong("leave_id"));
        l.setStudentId(rs.getLong("student_id"));
        l.setFromDate(rs.getDate("from_date").toLocalDate());
        l.setToDate(rs.getDate("to_date").toLocalDate());
        l.setReason(rs.getString("reason"));
        l.setStatus(rs.getString("status"));
        Long reviewedBy = rs.getObject("reviewed_by") != null ? rs.getLong("reviewed_by") : null;
        l.setReviewedBy(reviewedBy);
        return l;
    };

    public Long save(LeaveRequest l) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO leave_requests (student_id, from_date, to_date, reason, status) VALUES (?, ?, ?, ?, 'PENDING')",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setLong(1, l.getStudentId());
            ps.setDate(2, java.sql.Date.valueOf(l.getFromDate()));
            ps.setDate(3, java.sql.Date.valueOf(l.getToDate()));
            ps.setString(4, l.getReason());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public List<LeaveRequest> findByStudent(Long studentId) {
        return jdbcTemplate.query(
                "SELECT * FROM leave_requests WHERE student_id = ? ORDER BY applied_at DESC", ROW_MAPPER, studentId);
    }

    public List<LeaveRequest> findPending() {
        return jdbcTemplate.query(
                "SELECT * FROM leave_requests WHERE status = 'PENDING' ORDER BY applied_at", ROW_MAPPER);
    }

    public List<LeaveRequest> findAll() {
        return jdbcTemplate.query("SELECT * FROM leave_requests ORDER BY applied_at DESC", ROW_MAPPER);
    }

    public Optional<LeaveRequest> findById(Long id) {
        List<LeaveRequest> r = jdbcTemplate.query("SELECT * FROM leave_requests WHERE leave_id = ?", ROW_MAPPER, id);
        return r.stream().findFirst();
    }

    public void updateDecision(Long leaveId, String status, Long reviewerFacultyId) {
        jdbcTemplate.update(
                "UPDATE leave_requests SET status=?, reviewed_by=?, reviewed_at=NOW() WHERE leave_id=?",
                status, reviewerFacultyId, leaveId);
    }

    public long countPending() {
        Long c = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM leave_requests WHERE status='PENDING'", Long.class);
        return c != null ? c : 0;
    }
}

package com.college.attendance.service;

import com.college.attendance.dto.DashboardStatsDto;
import com.college.attendance.repository.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class AnalyticsService {

    private final StudentRepository studentRepository;
    private final FacultyRepository facultyRepository;
    private final SubjectRepository subjectRepository;
    private final AttendanceRepository attendanceRepository;
    private final LeaveRequestRepository leaveRequestRepository;
    private final AiPredictionRepository aiPredictionRepository;

    public AnalyticsService(StudentRepository studentRepository, FacultyRepository facultyRepository,
                             SubjectRepository subjectRepository, AttendanceRepository attendanceRepository,
                             LeaveRequestRepository leaveRequestRepository, AiPredictionRepository aiPredictionRepository) {
        this.studentRepository = studentRepository;
        this.facultyRepository = facultyRepository;
        this.subjectRepository = subjectRepository;
        this.attendanceRepository = attendanceRepository;
        this.leaveRequestRepository = leaveRequestRepository;
        this.aiPredictionRepository = aiPredictionRepository;
    }

    public DashboardStatsDto getDashboardStats() {
        DashboardStatsDto dto = new DashboardStatsDto();
        dto.setTotalStudents(studentRepository.count());
        dto.setTotalFaculty(facultyRepository.count());
        dto.setTotalSubjects(subjectRepository.count());
        dto.setTodayAttendanceMarked(attendanceRepository.countTodayMarked());
        dto.setPendingLeaveRequests(leaveRequestRepository.countPending());
        dto.setHighRiskStudents(aiPredictionRepository.countHighRisk());

        List<Map<String, Object>> overall = attendanceRepository.overallPercentagePerStudent();
        long below75 = overall.stream()
                .filter(r -> r.get("percentage") != null && ((Number) r.get("percentage")).doubleValue() < 75.0)
                .count();
        dto.setStudentsBelow75(below75);

        return dto;
    }

    /** Buckets students into >90%, 80-90%, 75-80%, <75% bands for analytics charts. */
    public Map<String, Long> attendanceBandDistribution() {
        List<Map<String, Object>> overall = attendanceRepository.overallPercentagePerStudent();
        long above90 = 0, band80to90 = 0, band75to80 = 0, below75 = 0;
        for (Map<String, Object> row : overall) {
            double pct = row.get("percentage") == null ? 0.0 : ((Number) row.get("percentage")).doubleValue();
            if (pct >= 90) above90++;
            else if (pct >= 80) band80to90++;
            else if (pct >= 75) band75to80++;
            else below75++;
        }
        return Map.of(
                "above90", above90,
                "band80to90", band80to90,
                "band75to80", band75to80,
                "below75", below75
        );
    }

    public List<Map<String, Object>> overallPercentagePerStudent() {
        return attendanceRepository.overallPercentagePerStudent();
    }

    public List<Map<String, Object>> subjectWiseOverall() {
        return attendanceRepository.subjectWiseOverall();
    }

    public List<Map<String, Object>> monthlyTrendOverall() {
        return attendanceRepository.monthlyTrendOverall();
    }

    public Map<String, Object> presentAbsentTotals() {
        return attendanceRepository.presentAbsentTotals();
    }
}

package com.college.attendance.controller;

import com.college.attendance.dto.ApiResponse;
import com.college.attendance.dto.DashboardStatsDto;
import com.college.attendance.service.AnalyticsService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/** Admin analytics & dashboard. Faculty dashboards reuse the same read-only data via /api/admin/analytics
 *  because the SessionAuthFilter grants ADMIN access everywhere, and FACULTY is granted access to
 *  its own /api/faculty/** endpoints below. */
@RestController
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    public AnalyticsController(AnalyticsService analyticsService) {
        this.analyticsService = analyticsService;
    }

    @GetMapping("/api/admin/analytics/dashboard")
    public ApiResponse<DashboardStatsDto> dashboard() {
        return ApiResponse.ok(analyticsService.getDashboardStats());
    }

    @GetMapping("/api/admin/analytics/bands")
    public ApiResponse<Map<String, Long>> bands() {
        return ApiResponse.ok(analyticsService.attendanceBandDistribution());
    }

    @GetMapping("/api/admin/analytics/overall")
    public ApiResponse<List<Map<String, Object>>> overall() {
        return ApiResponse.ok(analyticsService.overallPercentagePerStudent());
    }

    @GetMapping("/api/admin/analytics/subject-wise")
    public ApiResponse<List<Map<String, Object>>> subjectWise() {
        return ApiResponse.ok(analyticsService.subjectWiseOverall());
    }

    @GetMapping("/api/admin/analytics/monthly-trend")
    public ApiResponse<List<Map<String, Object>>> monthlyTrend() {
        return ApiResponse.ok(analyticsService.monthlyTrendOverall());
    }

    @GetMapping("/api/admin/analytics/present-absent")
    public ApiResponse<Map<String, Object>> presentAbsent() {
        return ApiResponse.ok(analyticsService.presentAbsentTotals());
    }

    // ---- FACULTY dashboard (read-only subset, same underlying data) ----
    @GetMapping("/api/faculty/analytics/dashboard")
    public ApiResponse<DashboardStatsDto> facultyDashboard() {
        return ApiResponse.ok(analyticsService.getDashboardStats());
    }

    @GetMapping("/api/faculty/analytics/bands")
    public ApiResponse<Map<String, Long>> facultyBands() {
        return ApiResponse.ok(analyticsService.attendanceBandDistribution());
    }
}

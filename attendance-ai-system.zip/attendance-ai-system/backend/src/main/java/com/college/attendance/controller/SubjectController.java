package com.college.attendance.controller;

import com.college.attendance.dto.ApiResponse;
import com.college.attendance.dto.SubjectRequest;
import com.college.attendance.model.Subject;
import com.college.attendance.service.SubjectService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/admin/subjects")
public class SubjectController {

    private final SubjectService subjectService;

    public SubjectController(SubjectService subjectService) {
        this.subjectService = subjectService;
    }

    @GetMapping
    public ApiResponse<List<Subject>> getAll() {
        return ApiResponse.ok(subjectService.getAll());
    }

    @PostMapping
    public ApiResponse<Subject> create(@Valid @RequestBody SubjectRequest request) {
        return ApiResponse.ok("Subject created successfully", subjectService.create(request));
    }

    @PostMapping("/{id}/assign")
    public ApiResponse<Object> assign(@PathVariable Long id, @RequestParam Long facultyId, @RequestParam String section) {
        subjectService.assignFaculty(id, facultyId, section);
        return ApiResponse.ok("Faculty assigned to subject successfully", null);
    }

    @DeleteMapping("/{id}")
    public ApiResponse<Object> delete(@PathVariable Long id) {
        subjectService.delete(id);
        return ApiResponse.ok("Subject deleted successfully", null);
    }
}

package com.college.attendance.config;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * Lightweight, dependency-free role-based access control.
 *
 * On login, AuthController stores "role" and "referenceId" in the HttpSession.
 * This filter checks that the session role matches the role segment of the
 * requested API path, so a STUDENT session cannot call /api/admin/** or
 * /api/faculty/** endpoints even by typing the URL directly, and vice versa.
 *
 * Public endpoints (login, health, static content) are excluded.
 */
@Component
public class SessionAuthFilter extends OncePerRequestFilter {

    private static final String[] PUBLIC_PATHS = {
            "/api/auth/login",
            "/api/auth/logout",
            "/api/health"
    };

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        String path = request.getRequestURI();

        if (!path.startsWith("/api/")) {
            filterChain.doFilter(request, response);
            return;
        }

        for (String publicPath : PUBLIC_PATHS) {
            if (path.startsWith(publicPath)) {
                filterChain.doFilter(request, response);
                return;
            }
        }

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("role") == null) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setContentType("application/json");
            response.getWriter().write("{\"success\":false,\"message\":\"Not authenticated. Please login.\"}");
            return;
        }

        String role = (String) session.getAttribute("role"); // ADMIN / FACULTY / STUDENT
        String rolePrefix = role.toLowerCase();

        // Endpoints are namespaced by role: /api/admin/**, /api/faculty/**, /api/student/**
        // /api/shared/** is accessible to any authenticated role (e.g. AI predictions, subjects lookup)
        boolean isNamespaced = path.startsWith("/api/admin/") || path.startsWith("/api/faculty/") || path.startsWith("/api/student/");

        if (isNamespaced && !path.startsWith("/api/" + rolePrefix + "/")) {
            // ADMIN is allowed to view everything faculty/student can (read-only oversight)
            if (!"admin".equals(rolePrefix)) {
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                response.setContentType("application/json");
                response.getWriter().write("{\"success\":false,\"message\":\"Access denied for role: " + role + "\"}");
                return;
            }
        }

        filterChain.doFilter(request, response);
    }
}

package com.college.attendance.controller;

import com.college.attendance.dto.ApiResponse;
import com.college.attendance.service.ReportService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
public class ReportController {

    private final ReportService reportService;

    @Value("${attendance.minimum-required}")
    private double minimumRequired;

    public ReportController(ReportService reportService) {
        this.reportService = reportService;
    }

    @GetMapping("/api/faculty/reports/daily")
    public ApiResponse<List<Map<String, Object>>> daily(@RequestParam(required = false) String date) {
        LocalDate d = (date == null || date.isBlank()) ? LocalDate.now() : LocalDate.parse(date);
        return ApiResponse.ok(reportService.dailyReport(d));
    }

    @GetMapping("/api/faculty/reports/monthly")
    public ApiResponse<List<Map<String, Object>>> monthly() {
        return ApiResponse.ok(reportService.monthlyReport());
    }

    @GetMapping("/api/faculty/reports/defaulters")
    public ApiResponse<List<Map<String, Object>>> defaulters() {
        return ApiResponse.ok(reportService.defaulterReport(minimumRequired));
    }
}

package com.college.attendance.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

public class LeaveApplyRequest {
    // studentId is intentionally NOT validated here - LeaveController always overwrites it
    // with the ID resolved from the authenticated STUDENT session, so client input is ignored.
    private Long studentId;
    @NotNull private LocalDate fromDate;
    @NotNull private LocalDate toDate;
    @NotBlank private String reason;

    public Long getStudentId() { return studentId; }
    public void setStudentId(Long studentId) { this.studentId = studentId; }
    public LocalDate getFromDate() { return fromDate; }
    public void setFromDate(LocalDate fromDate) { this.fromDate = fromDate; }
    public LocalDate getToDate() { return toDate; }
    public void setToDate(LocalDate toDate) { this.toDate = toDate; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
}

package com.college.attendance.repository;

import com.college.attendance.model.Faculty;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

@Repository
public class FacultyRepository {

    private final JdbcTemplate jdbcTemplate;

    public FacultyRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Faculty> ROW_MAPPER = (rs, rowNum) -> {
        Faculty f = new Faculty();
        f.setFacultyId(rs.getLong("faculty_id"));
        f.setFacultyCode(rs.getString("faculty_code"));
        f.setName(rs.getString("name"));
        f.setEmail(rs.getString("email"));
        f.setPhone(rs.getString("phone"));
        f.setDepartment(rs.getString("department"));
        return f;
    };

    public List<Faculty> findAll() {
        return jdbcTemplate.query("SELECT * FROM faculty ORDER BY name", ROW_MAPPER);
    }

    public Optional<Faculty> findById(Long id) {
        List<Faculty> r = jdbcTemplate.query("SELECT * FROM faculty WHERE faculty_id = ?", ROW_MAPPER, id);
        return r.stream().findFirst();
    }

    public Optional<Faculty> findByCode(String code) {
        List<Faculty> r = jdbcTemplate.query("SELECT * FROM faculty WHERE faculty_code = ?", ROW_MAPPER, code);
        return r.stream().findFirst();
    }

    public List<Faculty> search(String keyword) {
        String like = "%" + keyword + "%";
        return jdbcTemplate.query(
                "SELECT * FROM faculty WHERE name LIKE ? OR faculty_code LIKE ? OR department LIKE ? ORDER BY name",
                ROW_MAPPER, like, like, like);
    }

    public Long save(Faculty f) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO faculty (faculty_code, name, email, phone, department) VALUES (?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, f.getFacultyCode());
            ps.setString(2, f.getName());
            ps.setString(3, f.getEmail());
            ps.setString(4, f.getPhone());
            ps.setString(5, f.getDepartment());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public void update(Long id, Faculty f) {
        jdbcTemplate.update("UPDATE faculty SET name=?, email=?, phone=?, department=? WHERE faculty_id=?",
                f.getName(), f.getEmail(), f.getPhone(), f.getDepartment(), id);
    }

    public void deleteById(Long id) {
        jdbcTemplate.update("DELETE FROM faculty WHERE faculty_id = ?", id);
    }

    public long count() {
        Long c = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM faculty", Long.class);
        return c != null ? c : 0;
    }
}

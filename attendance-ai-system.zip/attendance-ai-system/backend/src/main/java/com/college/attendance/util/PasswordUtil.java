package com.college.attendance.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

/**
 * Password hashing utility.
 *
 * Uses a randomly generated 16-byte salt per password and 10,000 rounds of
 * SHA-256 (a manual key-stretching loop, similar in spirit to PBKDF2) so
 * that no dependency beyond the JDK's built-in java.security package is
 * required. Stored format: "<base64-salt>:<base64-hash>"
 *
 * This intentionally avoids pulling in an external crypto library so the
 * project has zero extra Maven dependencies for authentication.
 */
public final class PasswordUtil {

    private static final int SALT_LENGTH_BYTES = 16;
    private static final int ITERATIONS = 10_000;

    private PasswordUtil() {
    }

    public static String hashPassword(String plainPassword) {
        byte[] salt = new byte[SALT_LENGTH_BYTES];
        new SecureRandom().nextBytes(salt);
        byte[] hash = pbkdf2Like(plainPassword, salt);
        return Base64.getEncoder().encodeToString(salt) + ":" + Base64.getEncoder().encodeToString(hash);
    }

    public static boolean verifyPassword(String plainPassword, String storedHash) {
        if (storedHash == null || !storedHash.contains(":")) {
            return false;
        }
        String[] parts = storedHash.split(":", 2);
        byte[] salt = Base64.getDecoder().decode(parts[0]);
        byte[] expectedHash = Base64.getDecoder().decode(parts[1]);
        byte[] actualHash = pbkdf2Like(plainPassword, salt);
        return MessageDigest.isEqual(expectedHash, actualHash);
    }

    private static byte[] pbkdf2Like(String password, byte[] salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] result = concat(password.getBytes(java.nio.charset.StandardCharsets.UTF_8), salt);
            for (int i = 0; i < ITERATIONS; i++) {
                digest.reset();
                result = digest.digest(result);
            }
            return result;
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    private static byte[] concat(byte[] a, byte[] b) {
        byte[] out = new byte[a.length + b.length];
        System.arraycopy(a, 0, out, 0, a.length);
        System.arraycopy(b, 0, out, a.length, b.length);
        return out;
    }

    /** Utility entry point used only to generate demo password hashes for sample_data.sql */
    public static void main(String[] args) {
        String[] demoPasswords = {"admin123", "faculty123", "student123"};
        for (String pwd : demoPasswords) {
            System.out.println(pwd + " -> " + hashPassword(pwd));
        }
    }
}

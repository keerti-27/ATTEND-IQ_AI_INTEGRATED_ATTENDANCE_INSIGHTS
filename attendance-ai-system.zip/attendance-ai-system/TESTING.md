# TEST CASES — Attendance AI System

These are manual/functional test cases covering every module. Run them in order
against a freshly seeded database (schema.sql + sample_data.sql) with the Flask
AI service and Spring Boot backend both running.

| # | Test Case | Steps | Expected Result |
|---|-----------|-------|------------------|
| 1 | Valid login (Admin) | POST /api/auth/login with `admin`/`admin123`/`ADMIN` | 200 OK, session created, role=ADMIN returned |
| 2 | Valid login (Faculty) | POST /api/auth/login with `faculty1`/`faculty123`/`FACULTY` | 200 OK, role=FACULTY, referenceId=FAC001 |
| 3 | Valid login (Student) | POST /api/auth/login with `student1`/`student123`/`STUDENT` | 200 OK, role=STUDENT, referenceId=STU001 |
| 4 | Invalid password | Login with `admin`/`wrongpass`/`ADMIN` | 401 Unauthorized, "Invalid username, password, or role" |
| 5 | Invalid role for user | Login with `admin`/`admin123`/`STUDENT` | 401 Unauthorized (role mismatch — admin has no STUDENT record) |
| 6 | Role-based URL protection | Login as STUDENT, then call GET /api/admin/students directly | 403 Forbidden |
| 7 | No session access | Call GET /api/admin/students without logging in | 401 Unauthorized |
| 8 | Student creation | POST /api/admin/students with valid payload (unique code/email) | 201-style success, student appears in GET /api/admin/students |
| 9 | Duplicate student code | POST /api/admin/students with an existing student_code | 500/DB constraint error surfaced via GlobalExceptionHandler (unique constraint) |
| 10 | Faculty creation | POST /api/admin/faculty with valid payload | Success, faculty appears in list |
| 11 | Subject + assignment | POST /api/admin/subjects with facultyId + section | Subject created, row added to faculty_subjects |
| 12 | Mark attendance (first time) | Faculty POST /api/faculty/attendance/mark for a subject/date/roster | 200 OK, rows inserted into `attendance` |
| 13 | Duplicate attendance same day | Repeat test 12 for the same student+subject+date with a different status | Existing row is UPDATED (upsert), not duplicated — verify via unique key `uq_attendance_once` and row count unchanged |
| 14 | Attendance percentage calculation | GET /api/student/attendance/subject-wise for a student with 39 present / 50 total | percentage = 78.00 (rounded to 2 decimals) |
| 15 | Below-75% flag | GET /api/admin/analytics/overall for a student under 75% | Frontend renders "Attendance Below Required Level" badge |
| 16 | Leave application | STUDENT POST /api/student/leave/apply with valid from/to/reason | 200 OK, status=PENDING, row visible in /api/student/leave/mine |
| 17 | Invalid leave dates | POST /api/student/leave/apply with toDate before fromDate | 400 Bad Request, "'To date' cannot be before 'From date'" |
| 18 | Leave approval | FACULTY POST /api/faculty/leave/{id}/decide with decision=APPROVED | status becomes APPROVED, reviewed_by/reviewed_at populated |
| 19 | Leave rejection | FACULTY POST /api/faculty/leave/{id}/decide with decision=REJECTED | status becomes REJECTED |
| 20 | Re-review blocked | Call decide() again on an already-approved leave request | 400 Bad Request, "already been reviewed" |
| 21 | Notification generation | Mark a student ABSENT via test 12/13 | New row appears in `notifications` table with the exact message format, visible via /api/student/notifications/mine |
| 22 | AI prediction (valid) | FACULTY POST /api/faculty/ai/predict/{studentId} for a student with attendance history | 200 OK, predicted_attendance/risk_level/message returned from the real Flask model (not hard-coded) |
| 23 | AI prediction (no history) | POST predict for a student with zero attendance rows | 404, "No attendance history found ... cannot generate a prediction yet." |
| 24 | AI service down | Stop Flask app, retry test 22 | 500 error with a clear message that the AI service at http://localhost:5000 is unreachable |
| 25 | Report generation | GET /api/faculty/reports/monthly | Returns one row per student with percentage matching /api/admin/analytics/overall |
| 26 | Defaulter report | GET /api/faculty/reports/defaulters | Only returns students with percentage < 75.0 |
| 27 | Role authorization (Faculty→Admin) | Login as FACULTY, call GET /api/admin/faculty | 403 Forbidden |
| 28 | Role authorization (Admin→Faculty) | Login as ADMIN, call GET /api/faculty/attendance/my-subjects | Allowed (Admin override in SessionAuthFilter) |
| 29 | Logout | POST /api/auth/logout, then call any /api/admin/** endpoint with the old session | 401 Unauthorized (session invalidated) |
| 30 | CSV export | On any Reports page, click "Export CSV" | Browser downloads a valid CSV matching the on-screen table |

## AI Model Validation (ai_model/)

Run `python3 train_model.py` and confirm the printed metrics are non-zero and
plausible (not fabricated):

```
--- Regression Model (RandomForestRegressor) ---
MAE  : ~3.1
RMSE : ~4.1
R2   : ~0.92

--- Classification Model (RandomForestClassifier) ---
Accuracy: ~0.83
```

Exact numbers vary slightly by scikit-learn version but should stay in this
neighborhood given the fixed random seed (42) and the 300-record dataset.

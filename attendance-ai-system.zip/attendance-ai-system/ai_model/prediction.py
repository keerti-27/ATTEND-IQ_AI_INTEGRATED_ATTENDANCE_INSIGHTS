"""
prediction.py
Loads the trained models and exposes a single predict() function
that the Flask API (app.py) uses.
"""

import os

import joblib
import numpy as np
import pandas as pd

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

FEATURE_COLUMNS = [
    "current_attendance",
    "total_classes",
    "classes_attended",
    "classes_absent",
    "recent_absences",
    "leave_days",
    "previous_month_attendance",
    "attendance_trend",
]

# Configurable risk thresholds
LOW_THRESHOLD = 80.0
MEDIUM_THRESHOLD = 75.0

_regressor = None
_classifier = None


def _load_models():
    global _regressor, _classifier
    if _regressor is None or _classifier is None:
        reg_path = os.path.join(BASE_DIR, "attendance_model.pkl")
        clf_path = os.path.join(BASE_DIR, "risk_model.pkl")
        if not os.path.exists(reg_path) or not os.path.exists(clf_path):
            raise FileNotFoundError(
                "Model files not found. Run train_model.py first to train and save "
                "attendance_model.pkl and risk_model.pkl."
            )
        _regressor = joblib.load(reg_path)
        _classifier = joblib.load(clf_path)
    return _regressor, _classifier


def _risk_message(predicted_attendance: float, risk_level: str, current_attendance: float) -> str:
    if risk_level == "HIGH":
        return (
            "This student may fall below 75% attendance next month. "
            "Immediate attention and counselling is recommended."
        )
    if risk_level == "MEDIUM":
        return (
            "This student's attendance is trending close to the minimum requirement. "
            "Monitor closely over the next few weeks."
        )
    return "This student's attendance is healthy and likely to remain above 80%."


def validate_input(data: dict):
    missing = [c for c in FEATURE_COLUMNS if c not in data]
    if missing:
        raise ValueError(f"Missing required fields: {', '.join(missing)}")
    for c in FEATURE_COLUMNS:
        try:
            float(data[c])
        except (TypeError, ValueError):
            raise ValueError(f"Field '{c}' must be numeric")


def predict(data: dict) -> dict:
    """
    data: dict with keys matching FEATURE_COLUMNS
    returns: dict with predicted_attendance, risk_level, message
    """
    validate_input(data)
    regressor, classifier = _load_models()

    row = pd.DataFrame([{c: float(data[c]) for c in FEATURE_COLUMNS}])

    predicted_attendance = float(regressor.predict(row)[0])
    predicted_attendance = round(max(0.0, min(100.0, predicted_attendance)), 2)

    risk_level = str(classifier.predict(row)[0])

    # Cross-check classifier output against configurable thresholds for consistency
    if predicted_attendance >= LOW_THRESHOLD:
        threshold_risk = "LOW"
    elif predicted_attendance >= MEDIUM_THRESHOLD:
        threshold_risk = "MEDIUM"
    else:
        threshold_risk = "HIGH"

    # If model and threshold disagree, prefer the more cautious (higher risk) verdict
    risk_order = {"LOW": 0, "MEDIUM": 1, "HIGH": 2}
    final_risk = risk_level if risk_order[risk_level] >= risk_order[threshold_risk] else threshold_risk

    return {
        "predicted_attendance": predicted_attendance,
        "risk_level": final_risk,
        "message": _risk_message(predicted_attendance, final_risk, float(data["current_attendance"])),
    }

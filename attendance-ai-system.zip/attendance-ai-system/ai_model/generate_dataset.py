"""
generate_dataset.py
Generates a realistic synthetic dataset of student attendance history
used to train the attendance prediction models.

Run:
    python3 generate_dataset.py
Produces:
    dataset.csv (300 records)
"""

import numpy as np
import pandas as pd

np.random.seed(42)

N_RECORDS = 300


def clamp(value, low, high):
    return max(low, min(high, value))


rows = []
for i in range(1, N_RECORDS + 1):
    student_id = f"STU{i:04d}"

    # Base ability of a student to attend classes (drives correlated features)
    base_reliability = clamp(np.random.normal(80, 12), 40, 100)

    total_classes = int(np.random.randint(40, 90))

    # Attendance rate influenced by base_reliability with noise
    attendance_rate = clamp(base_reliability + np.random.normal(0, 5), 20, 100)
    classes_attended = int(round(total_classes * attendance_rate / 100))
    classes_attended = clamp(classes_attended, 0, total_classes)
    classes_absent = total_classes - classes_attended

    current_attendance = round((classes_attended / total_classes) * 100, 2) if total_classes else 0.0

    # Recent absences (last 2 weeks)
    recent_absences = clamp(int(np.random.poisson(1.5)), 0, 10)

    leave_days = clamp(int(np.random.poisson(1.2)), 0, 8)

    # Previous month attendance - noisy version of current attendance
    previous_month_attendance = round(clamp(current_attendance + np.random.normal(2, 6), 0, 100), 2)

    # Attendance trend = current - previous (negative means declining)
    attendance_trend = round(current_attendance - previous_month_attendance, 2)

    # Future attendance (target) - depends on current, trend continuation, recent absences, leave days
    trend_continuation = attendance_trend * 0.6
    absence_penalty = recent_absences * 1.2
    leave_penalty = leave_days * 0.8
    noise = np.random.normal(0, 3)

    future_attendance = current_attendance + trend_continuation - absence_penalty - leave_penalty + noise
    future_attendance = round(clamp(future_attendance, 0, 100), 2)

    rows.append({
        "student_id": student_id,
        "current_attendance": current_attendance,
        "total_classes": total_classes,
        "classes_attended": classes_attended,
        "classes_absent": classes_absent,
        "recent_absences": recent_absences,
        "leave_days": leave_days,
        "previous_month_attendance": previous_month_attendance,
        "attendance_trend": attendance_trend,
        "future_attendance": future_attendance,
    })

df = pd.DataFrame(rows)
df.to_csv("dataset.csv", index=False)
print(f"Generated dataset.csv with {len(df)} records")
print(df.describe())

"""
app.py
Flask AI Prediction API.

Endpoints:
    GET  /health          -> {"status": "UP"}
    POST /predict          -> real ML prediction using trained RandomForest models

Run:
    python3 app.py
Server starts on http://localhost:5000

The Java Spring Boot backend calls POST /predict for every AI prediction
request (see AiPredictionService.java on the Java side).
"""

from flask import Flask, jsonify, request

from prediction import predict

app = Flask(__name__)


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "UP"}), 200


@app.route("/predict", methods=["POST"])
def predict_endpoint():
    if not request.is_json:
        return jsonify({"error": "Request body must be JSON"}), 400

    data = request.get_json()

    try:
        result = predict(data)
        return jsonify(result), 200
    except ValueError as ve:
        return jsonify({"error": str(ve)}), 400
    except FileNotFoundError as fe:
        return jsonify({"error": str(fe)}), 500
    except Exception as e:  # pragma: no cover - safety net
        return jsonify({"error": f"Prediction failed: {str(e)}"}), 500


if __name__ == "__main__":
    # Port 5000 is used consistently in application.properties (ai.service.url)
    app.run(host="0.0.0.0", port=5000, debug=False)

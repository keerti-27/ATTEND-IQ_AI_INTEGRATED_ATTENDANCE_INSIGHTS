"""
train_model.py
Trains two real scikit-learn models on dataset.csv:

1. RandomForestRegressor -> predicts future_attendance (%)
2. RandomForestClassifier -> predicts risk_level (LOW / MEDIUM / HIGH)

Run:
    python3 train_model.py

Produces:
    attendance_model.pkl
    risk_model.pkl
    metrics.json   (MAE, RMSE, R2, classifier accuracy -- ACTUAL values, not fabricated)
"""

import json

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    mean_absolute_error,
    mean_squared_error,
    r2_score,
)
from sklearn.model_selection import train_test_split

FEATURE_COLUMNS = [
    "current_attendance",
    "total_classes",
    "classes_attended",
    "classes_absent",
    "recent_absences",
    "leave_days",
    "previous_month_attendance",
    "attendance_trend",
]

# Configurable risk thresholds (also mirrored in app.py / prediction.py)
LOW_THRESHOLD = 80.0
MEDIUM_THRESHOLD = 75.0


def risk_from_attendance(pct: float) -> str:
    if pct >= LOW_THRESHOLD:
        return "LOW"
    if pct >= MEDIUM_THRESHOLD:
        return "MEDIUM"
    return "HIGH"


def main():
    df = pd.read_csv("dataset.csv")
    print(f"Loaded {len(df)} records from dataset.csv")

    X = df[FEATURE_COLUMNS]
    y_reg = df["future_attendance"]
    y_clf = df["future_attendance"].apply(risk_from_attendance)

    # ---- Regression model: predicts future attendance percentage ----
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_reg, test_size=0.2, random_state=42
    )

    regressor = RandomForestRegressor(
        n_estimators=200, max_depth=8, random_state=42, n_jobs=-1
    )
    regressor.fit(X_train, y_train)

    y_pred = regressor.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
    r2 = r2_score(y_test, y_pred)

    print("\n--- Regression Model (RandomForestRegressor) ---")
    print(f"MAE  : {mae:.3f}")
    print(f"RMSE : {rmse:.3f}")
    print(f"R2   : {r2:.3f}")

    # ---- Classification model: predicts risk level ----
    Xc_train, Xc_test, yc_train, yc_test = train_test_split(
        X, y_clf, test_size=0.2, random_state=42, stratify=y_clf
    )

    classifier = RandomForestClassifier(
        n_estimators=200, max_depth=8, random_state=42, n_jobs=-1
    )
    classifier.fit(Xc_train, yc_train)

    yc_pred = classifier.predict(Xc_test)
    accuracy = accuracy_score(yc_test, yc_pred)
    report = classification_report(yc_test, yc_pred, output_dict=True)

    print("\n--- Classification Model (RandomForestClassifier) ---")
    print(f"Accuracy: {accuracy:.3f}")
    print(classification_report(yc_test, yc_pred))

    # ---- Save models ----
    joblib.dump(regressor, "attendance_model.pkl")
    joblib.dump(classifier, "risk_model.pkl")
    print("\nSaved attendance_model.pkl and risk_model.pkl")

    metrics = {
        "regression": {"MAE": round(mae, 3), "RMSE": round(rmse, 3), "R2": round(r2, 3)},
        "classification": {"accuracy": round(accuracy, 3), "report": report},
        "feature_columns": FEATURE_COLUMNS,
        "risk_thresholds": {"LOW": LOW_THRESHOLD, "MEDIUM": MEDIUM_THRESHOLD},
        "training_records": len(df),
    }
    with open("metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)
    print("Saved metrics.json")


if __name__ == "__main__":
    main()

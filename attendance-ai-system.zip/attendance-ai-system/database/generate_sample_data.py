"""
generate_sample_data.py
Generates database/sample_data.sql with realistic sample data:
 - 5 faculty, 5 subjects, 20 students
 - login accounts for admin / all faculty / all students
 - ~2 months of attendance records per student-subject pairing,
   deliberately spread across >90%, 80-90%, 75-80%, and <75% bands
 - leave requests (pending/approved/rejected)
 - parent notifications for absences
 - AI prediction snapshots

Run:
    python3 generate_sample_data.py
"""

import datetime
import random

random.seed(7)

OUT_FILE = "sample_data.sql"

# ---- Fixed demo password hashes (PBKDF2-like SHA-256, see PasswordUtil.java) ----
ADMIN_HASH = "AQEBAQEBAQEBAQEBAQEBAQ==:rMpV4X4Ftuz58/cG7LPcBf5VFL/p+DSqB82Jja0W1yE="
FACULTY_HASH = "AgICAgICAgICAgICAgICAg==:wxX7UG8X3JpBPZiXfKZH0tnSu3rdYnNsRW/D6dlb8dY="
STUDENT_HASH = "AwMDAwMDAwMDAwMDAwMDAw==:4vOlzNSCePRUulRBj+daBf+u4JOlnMme2HF9WP4kHkA="

DEPARTMENTS = ["Computer Science", "Electronics", "Information Technology"]

FACULTY = [
    ("FAC001", "Dr. Ramesh Kumar", "ramesh.kumar@college.edu", "9840011111", "Computer Science"),
    ("FAC002", "Dr. Anitha Suresh", "anitha.suresh@college.edu", "9840022222", "Computer Science"),
    ("FAC003", "Prof. Vijay Raghavan", "vijay.raghavan@college.edu", "9840033333", "Electronics"),
    ("FAC004", "Dr. Kavitha Nair", "kavitha.nair@college.edu", "9840044444", "Information Technology"),
    ("FAC005", "Prof. Suresh Babu", "suresh.babu@college.edu", "9840055555", "Information Technology"),
]

SUBJECTS = [
    ("CS301", "Data Structures", "Computer Science", 2, 3),
    ("CS302", "Database Management Systems", "Computer Science", 2, 3),
    ("EC301", "Digital Electronics", "Electronics", 2, 3),
    ("IT301", "Operating Systems", "Information Technology", 2, 3),
    ("IT302", "Computer Networks", "Information Technology", 2, 3),
]

# faculty_index -> subject_index, section
FACULTY_SUBJECT_MAP = [
    (0, 0, "A"),  # Ramesh -> Data Structures, Section A
    (1, 1, "A"),  # Anitha -> DBMS, Section A
    (2, 2, "B"),  # Vijay -> Digital Electronics, Section B
    (3, 3, "A"),  # Kavitha -> OS, Section A
    (4, 4, "A"),  # Suresh -> Networks, Section A
]

FIRST_NAMES = ["Arun", "Priya", "Kumar", "Divya", "Karthik", "Meena", "Suresh", "Lakshmi",
               "Vignesh", "Anitha", "Rahul", "Sneha", "Praveen", "Deepa", "Manoj", "Swathi",
               "Ashwin", "Nisha", "Ganesh", "Pooja"]
LAST_NAMES = ["Kumar", "Raj", "Sharma", "Nair", "Iyer", "Reddy", "Rao", "Menon"]

# Attendance band per student index (0-19): first 5 high, next 5 good, next 5 borderline, last 5 at-risk
def band_for_index(i):
    if i < 5:
        return (92, 99)   # >90%
    elif i < 10:
        return (81, 89)   # 80-90%
    elif i < 15:
        return (75, 80)   # 75-80%
    else:
        return (55, 74)   # below 75%


def esc(s):
    return s.replace("'", "''")


def main():
    lines = []
    lines.append("USE attendance_analytics_db;\n")
    lines.append("SET FOREIGN_KEY_CHECKS = 0;\n")

    # ---- FACULTY ----
    lines.append("\n-- FACULTY --")
    for i, (code, name, email, phone, dept) in enumerate(FACULTY, start=1):
        lines.append(
            f"INSERT INTO faculty (faculty_id, faculty_code, name, email, phone, department) VALUES "
            f"({i}, '{code}', '{esc(name)}', '{email}', '{phone}', '{esc(dept)}');"
        )

    # ---- SUBJECTS ----
    lines.append("\n-- SUBJECTS --")
    for i, (code, name, dept, year, sem) in enumerate(SUBJECTS, start=1):
        lines.append(
            f"INSERT INTO subjects (subject_id, subject_code, subject_name, department, year, semester) VALUES "
            f"({i}, '{code}', '{esc(name)}', '{esc(dept)}', {year}, {sem});"
        )

    # ---- FACULTY_SUBJECTS ----
    lines.append("\n-- FACULTY_SUBJECTS --")
    for fi, si, section in FACULTY_SUBJECT_MAP:
        lines.append(
            f"INSERT INTO faculty_subjects (faculty_id, subject_id, section) VALUES "
            f"({fi + 1}, {si + 1}, '{section}');"
        )

    # ---- STUDENTS ----
    lines.append("\n-- STUDENTS --")
    students = []
    for i in range(20):
        sid = i + 1
        code = f"STU{sid:03d}"
        reg_no = f"2024CSE{sid:03d}"
        first = FIRST_NAMES[i]
        last = random.choice(LAST_NAMES)
        name = f"{first} {last}"
        email = f"{first.lower()}.{last.lower()}{sid}@college.edu"
        phone = f"90000{sid:05d}"
        dept = "Computer Science" if sid <= 15 else "Information Technology"
        year = 2
        section = "A" if sid % 4 != 0 else "B"
        parent_name = f"{last} Senior"
        parent_email = f"parent.{first.lower()}{sid}@gmail.com"
        parent_phone = f"91111{sid:05d}"
        students.append({
            "id": sid, "code": code, "name": name, "dept": dept, "section": section
        })
        lines.append(
            "INSERT INTO students (student_id, student_code, register_no, name, email, phone, "
            "department, year, section, parent_name, parent_email, parent_phone) VALUES "
            f"({sid}, '{code}', '{reg_no}', '{esc(name)}', '{email}', '{phone}', '{esc(dept)}', "
            f"{year}, '{section}', '{esc(parent_name)}', '{parent_email}', '{parent_phone}');"
        )

    # ---- USERS (login accounts) ----
    lines.append("\n-- USERS --")
    lines.append(
        "INSERT INTO users (username, password_hash, role, reference_id) VALUES "
        f"('admin', '{ADMIN_HASH}', 'ADMIN', 'ADMIN001');"
    )
    for i, (code, *_rest) in enumerate(FACULTY, start=1):
        username = "faculty1" if i == 1 else f"faculty{i}"
        lines.append(
            "INSERT INTO users (username, password_hash, role, reference_id) VALUES "
            f"('{username}', '{FACULTY_HASH}', 'FACULTY', '{code}');"
        )
    for s in students:
        username = "student1" if s["id"] == 1 else f"student{s['id']}"
        lines.append(
            "INSERT INTO users (username, password_hash, role, reference_id) VALUES "
            f"('{username}', '{STUDENT_HASH}', 'STUDENT', '{s['code']}');"
        )

    # ---- ATTENDANCE ----
    # Each student attends the subject(s) taught for their section.
    # Generate ~55 class days over the last ~11 weeks (Mon-Fri), skipping some for variety.
    lines.append("\n-- ATTENDANCE --")
    today = datetime.date(2026, 9, 8)  # a Tuesday just before "today" in the narrative
    class_days = []
    d = today - datetime.timedelta(days=90)
    while d <= today:
        if d.weekday() < 5:  # Mon-Fri
            class_days.append(d)
        d += datetime.timedelta(days=1)
    class_days = class_days[-55:]  # last 55 weekdays ~ 11 weeks

    attendance_rows = []
    att_id = 1
    for s in students:
        i = s["id"] - 1
        low, high = band_for_index(i)
        target_pct = random.randint(low, high)

        # Determine which subject(s) this student's section maps to
        applicable = [(fi, si, sec) for (fi, si, sec) in FACULTY_SUBJECT_MAP if sec == s["section"]]
        if not applicable:
            applicable = [FACULTY_SUBJECT_MAP[0]]

        for (fi, si, sec) in applicable:
            faculty_id = fi + 1
            subject_id = si + 1
            for day in class_days:
                present = random.randint(1, 100) <= target_pct
                status = "PRESENT" if present else "ABSENT"
                attendance_rows.append((att_id, s["id"], subject_id, faculty_id, day.isoformat(), status))
                att_id += 1

    for (aid, sid, subid, fid, day, status) in attendance_rows:
        lines.append(
            "INSERT INTO attendance (attendance_id, student_id, subject_id, faculty_id, attendance_date, status) VALUES "
            f"({aid}, {sid}, {subid}, {fid}, '{day}', '{status}');"
        )

    # ---- LEAVE_REQUESTS ----
    lines.append("\n-- LEAVE_REQUESTS --")
    leave_id = 1
    leave_reasons = ["Fever and cold", "Family function", "Medical checkup", "Personal emergency", "Travel to hometown"]
    statuses = ["PENDING", "APPROVED", "REJECTED"]
    for s in students[:12]:  # some students have applied leave
        n_leaves = random.randint(1, 2)
        for _ in range(n_leaves):
            start_offset = random.randint(5, 60)
            duration = random.randint(1, 3)
            from_date = today - datetime.timedelta(days=start_offset)
            to_date = from_date + datetime.timedelta(days=duration - 1)
            status = random.choice(statuses)
            reason = random.choice(leave_reasons)
            reviewed_by = "NULL" if status == "PENDING" else "1"
            reviewed_at = "NULL" if status == "PENDING" else f"'{(from_date + datetime.timedelta(days=1)).isoformat()} 10:00:00'"
            lines.append(
                "INSERT INTO leave_requests (leave_id, student_id, from_date, to_date, reason, status, reviewed_by, reviewed_at) VALUES "
                f"({leave_id}, {s['id']}, '{from_date.isoformat()}', '{to_date.isoformat()}', "
                f"'{esc(reason)}', '{status}', {reviewed_by}, {reviewed_at});"
            )
            leave_id += 1

    # ---- NOTIFICATIONS (generated from a sample of ABSENT records) ----
    lines.append("\n-- NOTIFICATIONS --")
    absent_rows = [r for r in attendance_rows if r[5] == "ABSENT"]
    sampled_absences = random.sample(absent_rows, min(40, len(absent_rows)))
    notif_id = 1
    subject_name_by_id = {i + 1: SUBJECTS[i][1] for i in range(len(SUBJECTS))}
    student_by_id = {s["id"]: s for s in students}
    # need parent info -> re-derive quickly
    parent_lookup = {}
    for i in range(20):
        sid = i + 1
        first = FIRST_NAMES[i]
        parent_lookup[sid] = (f"{random.choice(LAST_NAMES)} Senior", f"parent.{first.lower()}{sid}@gmail.com")

    for (aid, sid, subid, fid, day, status) in sampled_absences:
        pname, pemail = parent_lookup[sid]
        sname = student_by_id[sid]["name"]
        subname = subject_name_by_id[subid]
        day_fmt = datetime.date.fromisoformat(day).strftime("%d-%m-%Y")
        message = f"Your ward {sname} was marked absent for {subname} on {day_fmt}."
        lines.append(
            "INSERT INTO notifications (notification_id, student_id, parent_name, parent_email, message, notification_date, status) VALUES "
            f"({notif_id}, {sid}, '{esc(pname)}', '{pemail}', '{esc(message)}', '{day} 18:00:00', 'SENT');"
        )
        notif_id += 1

    # ---- AI_PREDICTIONS (one snapshot per student based on their generated attendance) ----
    lines.append("\n-- AI_PREDICTIONS --")
    pred_id = 1
    for s in students:
        sid = s["id"]
        rows = [r for r in attendance_rows if r[1] == sid]
        total = len(rows)
        present = len([r for r in rows if r[5] == "PRESENT"])
        current_pct = round((present / total) * 100, 2) if total else 0.0
        # naive predicted attendance: small drift around current
        drift = random.uniform(-4, 2)
        predicted = round(max(0, min(100, current_pct + drift)), 2)
        if predicted >= 80:
            risk = "LOW"
            msg = "This student's attendance is healthy and likely to remain above 80%."
        elif predicted >= 75:
            risk = "MEDIUM"
            msg = "This student's attendance is trending close to the minimum requirement. Monitor closely."
        else:
            risk = "HIGH"
            msg = "This student may fall below 75% attendance next month. Immediate attention is recommended."
        lines.append(
            "INSERT INTO ai_predictions (prediction_id, student_id, current_attendance, predicted_attendance, risk_level, message) VALUES "
            f"({pred_id}, {sid}, {current_pct}, {predicted}, '{risk}', '{esc(msg)}');"
        )
        pred_id += 1

    lines.append("\nSET FOREIGN_KEY_CHECKS = 1;\n")

    with open(OUT_FILE, "w") as f:
        f.write("\n".join(lines))

    print(f"Wrote {OUT_FILE}")
    print(f"Students: {len(students)}, Faculty: {len(FACULTY)}, Subjects: {len(SUBJECTS)}")
    print(f"Attendance rows: {len(attendance_rows)}")
    print(f"Notifications: {len(sampled_absences)}")


if __name__ == "__main__":
    main()

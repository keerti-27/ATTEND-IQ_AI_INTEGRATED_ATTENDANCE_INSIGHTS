-- =====================================================================
-- attendance_analytics_db
-- AI-Integrated Automated Student Attendance Monitoring & Analytics System
-- =====================================================================

DROP DATABASE IF EXISTS attendance_analytics_db;
CREATE DATABASE attendance_analytics_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE attendance_analytics_db;

-- ---------------------------------------------------------------------
-- USERS  (login/auth table shared by all 3 roles)
-- ---------------------------------------------------------------------
CREATE TABLE users (
    user_id       BIGINT AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(50)  NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role          ENUM('ADMIN','FACULTY','STUDENT') NOT NULL,
    reference_id  VARCHAR(20)  NOT NULL,   -- FK-like link to students.student_code or faculty.faculty_code
    is_active     BOOLEAN NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_users_role (role),
    INDEX idx_users_reference (reference_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- STUDENTS
-- ---------------------------------------------------------------------
CREATE TABLE students (
    student_id    BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_code  VARCHAR(20)  NOT NULL UNIQUE,     -- e.g. STU001
    register_no   VARCHAR(30)  NOT NULL UNIQUE,
    name          VARCHAR(100) NOT NULL,
    email         VARCHAR(120) NOT NULL UNIQUE,
    phone         VARCHAR(15)  NOT NULL,
    department    VARCHAR(60)  NOT NULL,
    year          INT          NOT NULL,
    section       VARCHAR(10)  NOT NULL,
    parent_name   VARCHAR(100) NOT NULL,
    parent_email  VARCHAR(120) NOT NULL,
    parent_phone  VARCHAR(15)  NOT NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_students_dept_year (department, year, section)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- FACULTY
-- ---------------------------------------------------------------------
CREATE TABLE faculty (
    faculty_id    BIGINT AUTO_INCREMENT PRIMARY KEY,
    faculty_code  VARCHAR(20)  NOT NULL UNIQUE,     -- e.g. FAC001
    name          VARCHAR(100) NOT NULL,
    email         VARCHAR(120) NOT NULL UNIQUE,
    phone         VARCHAR(15)  NOT NULL,
    department    VARCHAR(60)  NOT NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- SUBJECTS
-- ---------------------------------------------------------------------
CREATE TABLE subjects (
    subject_id    BIGINT AUTO_INCREMENT PRIMARY KEY,
    subject_code  VARCHAR(20)  NOT NULL UNIQUE,
    subject_name  VARCHAR(100) NOT NULL,
    department    VARCHAR(60)  NOT NULL,
    year          INT          NOT NULL,
    semester      INT          NOT NULL,
    created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- FACULTY_SUBJECTS  (faculty <-> subject assignment, many-to-many)
-- ---------------------------------------------------------------------
CREATE TABLE faculty_subjects (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    faculty_id    BIGINT NOT NULL,
    subject_id    BIGINT NOT NULL,
    section       VARCHAR(10) NOT NULL,
    CONSTRAINT fk_fs_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) ON DELETE CASCADE,
    CONSTRAINT fk_fs_subject FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE,
    UNIQUE KEY uq_faculty_subject_section (faculty_id, subject_id, section)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- ATTENDANCE
-- ---------------------------------------------------------------------
CREATE TABLE attendance (
    attendance_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id    BIGINT NOT NULL,
    subject_id    BIGINT NOT NULL,
    faculty_id    BIGINT NOT NULL,
    attendance_date DATE NOT NULL,
    status        ENUM('PRESENT','ABSENT') NOT NULL,
    marked_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_att_student FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_att_subject FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE,
    CONSTRAINT fk_att_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id) ON DELETE CASCADE,
    UNIQUE KEY uq_attendance_once (student_id, subject_id, attendance_date),
    INDEX idx_att_date (attendance_date),
    INDEX idx_att_student_subject (student_id, subject_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- LEAVE_REQUESTS
-- ---------------------------------------------------------------------
CREATE TABLE leave_requests (
    leave_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id    BIGINT NOT NULL,
    from_date     DATE NOT NULL,
    to_date       DATE NOT NULL,
    reason        VARCHAR(500) NOT NULL,
    status        ENUM('PENDING','APPROVED','REJECTED') NOT NULL DEFAULT 'PENDING',
    reviewed_by   BIGINT NULL,
    applied_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reviewed_at   TIMESTAMP NULL,
    CONSTRAINT fk_leave_student FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_leave_faculty FOREIGN KEY (reviewed_by) REFERENCES faculty(faculty_id) ON DELETE SET NULL,
    CONSTRAINT chk_leave_dates CHECK (to_date >= from_date),
    INDEX idx_leave_status (status)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- NOTIFICATIONS  (parent notifications)
-- ---------------------------------------------------------------------
CREATE TABLE notifications (
    notification_id BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id       BIGINT NOT NULL,
    parent_name      VARCHAR(100) NOT NULL,
    parent_email     VARCHAR(120) NOT NULL,
    message          VARCHAR(500) NOT NULL,
    notification_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status           ENUM('PENDING','SENT','FAILED') NOT NULL DEFAULT 'SENT',
    CONSTRAINT fk_notif_student FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    INDEX idx_notif_student (student_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- AI_PREDICTIONS
-- ---------------------------------------------------------------------
CREATE TABLE ai_predictions (
    prediction_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
    student_id         BIGINT NOT NULL,
    current_attendance DECIMAL(5,2) NOT NULL,
    predicted_attendance DECIMAL(5,2) NOT NULL,
    risk_level          ENUM('LOW','MEDIUM','HIGH') NOT NULL,
    message              VARCHAR(500) NOT NULL,
    predicted_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_pred_student FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    INDEX idx_pred_student (student_id)
) ENGINE=InnoDB;

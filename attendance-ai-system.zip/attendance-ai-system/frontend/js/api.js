/**
 * api.js - shared fetch wrapper for the whole frontend.
 * Sends/receives the JSESSIONID cookie so session-based auth on the
 * Spring Boot backend works automatically.
 */
const API_BASE = "http://localhost:8080/api";

async function apiRequest(path, method = "GET", body = null) {
  const options = {
    method,
    credentials: "include",
    headers: { "Content-Type": "application/json" },
  };
  if (body !== null) options.body = JSON.stringify(body);

  let response;
  try {
    response = await fetch(API_BASE + path, options);
  } catch (err) {
    throw new Error("Cannot reach the backend server at " + API_BASE + ". Is Spring Boot running?");
  }

  let json;
  try {
    json = await response.json();
  } catch (err) {
    throw new Error("Server returned an unexpected response (status " + response.status + ")");
  }

  if (!response.ok || json.success === false) {
    throw new Error(json.message || "Request failed (status " + response.status + ")");
  }
  return json.data;
}

const api = {
  get: (path) => apiRequest(path, "GET"),
  post: (path, body) => apiRequest(path, "POST", body),
  put: (path, body) => apiRequest(path, "PUT", body),
  del: (path) => apiRequest(path, "DELETE"),
};

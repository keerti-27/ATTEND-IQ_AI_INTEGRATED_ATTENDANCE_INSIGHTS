/**
 * auth.js - login page logic + route guarding used by every dashboard page.
 */

function currentSession() {
  const raw = sessionStorage.getItem("attendance_session");
  return raw ? JSON.parse(raw) : null;
}

function requireRole(expectedRole) {
  const session = currentSession();
  if (!session || session.role !== expectedRole) {
    window.location.href = computeLoginPath();
  }
  return session;
}

function computeLoginPath() {
  // Works whether the current page is at /admin/xyz.html, /faculty/xyz.html, /student/xyz.html
  const depth = window.location.pathname.includes("/admin/")
    || window.location.pathname.includes("/faculty/")
    || window.location.pathname.includes("/student/");
  return depth ? "../login.html" : "login.html";
}

async function logout() {
  try { await api.post("/auth/logout", {}); } catch (e) { /* ignore */ }
  sessionStorage.removeItem("attendance_session");
  window.location.href = computeLoginPath();
}

async function handleLoginSubmit(event) {
  event.preventDefault();
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value;
  const role = document.getElementById("role").value;
  const errorBox = document.getElementById("loginError");
  errorBox.style.display = "none";

  try {
    const data = await api.post("/auth/login", { username, password, role });
    sessionStorage.setItem("attendance_session", JSON.stringify(data));
    if (data.role === "ADMIN") window.location.href = "admin/dashboard.html";
    else if (data.role === "FACULTY") window.location.href = "faculty/dashboard.html";
    else window.location.href = "student/dashboard.html";
  } catch (err) {
    errorBox.textContent = err.message;
    errorBox.style.display = "block";
  }
}

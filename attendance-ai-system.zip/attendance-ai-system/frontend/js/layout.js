/**
 * layout.js - builds the sidebar + topbar shell shared by every dashboard page.
 * Each page calls renderShell({ role, active, title, contentHtml }) once, then
 * wires up its own data-loading logic.
 */

const NAV_ITEMS = {
  ADMIN: [
    { key: "dashboard", label: "Dashboard", href: "dashboard.html" },
    { key: "students", label: "Students", href: "students.html" },
    { key: "faculty", label: "Faculty", href: "faculty.html" },
    { key: "subjects", label: "Subjects", href: "subjects.html" },
    { key: "attendance", label: "Attendance", href: "attendance.html" },
    { key: "analytics", label: "Analytics", href: "analytics.html" },
    { key: "ai", label: "AI Predictions", href: "ai-predictions.html" },
    { key: "leave", label: "Leave Management", href: "leave.html" },
    { key: "notifications", label: "Notifications", href: "notifications.html" },
    { key: "reports", label: "Reports", href: "reports.html" },
  ],
  FACULTY: [
    { key: "dashboard", label: "Dashboard", href: "dashboard.html" },
    { key: "attendance", label: "Mark Attendance", href: "attendance.html" },
    { key: "ai", label: "AI Predictions", href: "ai-predictions.html" },
    { key: "leave", label: "Leave Requests", href: "leave.html" },
    { key: "notifications", label: "Notifications", href: "notifications.html" },
    { key: "reports", label: "Reports", href: "reports.html" },
  ],
  STUDENT: [
    { key: "dashboard", label: "Dashboard", href: "dashboard.html" },
    { key: "attendance", label: "My Attendance", href: "attendance.html" },
    { key: "leave", label: "Leave", href: "leave.html" },
    { key: "ai", label: "AI Prediction", href: "ai-prediction.html" },
    { key: "notifications", label: "Notifications", href: "notifications.html" },
  ],
};

function renderShell({ role, active, title }) {
  const session = requireRole(role);
  const items = NAV_ITEMS[role];

  const navHtml = items.map(item => `
    <a href="${item.href}" class="${item.key === active ? 'active' : ''}">${item.label}</a>
  `).join("");

  document.getElementById("appShell").innerHTML = `
    <div class="app-shell">
      <aside class="sidebar">
        <div class="brand">🎓 Attendance AI</div>
        <nav>${navHtml}</nav>
        <button class="logout-btn" onclick="logout()">⎋ Logout</button>
      </aside>
      <main class="main-content">
        <div class="topbar">
          <h1>${title}</h1>
          <div class="user-chip">👤 ${session.displayName} &nbsp;•&nbsp; ${session.role}</div>
        </div>
        <div id="pageContent"></div>
      </main>
    </div>
  `;
  return session;
}

function riskBadge(risk) {
  const cls = risk === "LOW" ? "badge-risk-low" : risk === "MEDIUM" ? "badge-risk-medium" : "badge-risk-high";
  return `<span class="badge ${cls}">${risk}</span>`;
}

function statusBadge(status) {
  const map = {
    PRESENT: "badge-status-present", ABSENT: "badge-status-absent",
    PENDING: "badge-status-pending", APPROVED: "badge-status-approved", REJECTED: "badge-status-rejected",
  };
  return `<span class="badge ${map[status] || 'badge-status-pending'}">${status}</span>`;
}

function showAlert(containerId, message, type = "danger") {
  const el = document.getElementById(containerId);
  if (!el) return;
  el.innerHTML = `<div class="alert-box alert-${type}" style="background:${type === 'danger' ? '#fde2e1' : '#dff6ea'}; color:${type === 'danger' ? '#a33' : '#186b45'}">${message}</div>`;
}
